ToscaWidgets 
============

ToscaWidgets is a web widget toolkit for Python to aid in the creation,
packaging and distribution of common view elements normally used in the web.

tw2.forms contains the basic form widgets.

