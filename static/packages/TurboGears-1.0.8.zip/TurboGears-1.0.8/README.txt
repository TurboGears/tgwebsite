TurboGears
==========

Front-to-back web development megaframework.

TurboGears joins CherryPy, Kid, MochiKit and SQLObject to provide
a comprehensive web development toolkit.

TurboGears is licensed under an MIT-style license (see LICENSE.txt).
Other incorporated projects may be licensed under different licenses.
All licenses allow for non-commercial and commercial use.

