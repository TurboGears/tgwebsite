import unittest
import cherrypy
import turbogears
from turbogears import testutil, database, identity
from turbogears.identity.soprovider import TG_User, TG_Group, TG_Permission

#hub = database.AutoConnectHub("sqlite:///:memory:")
hub = database.PackageHub("turbogears.identity")

class RestrictedArea(turbogears.controllers.Controller, identity.SecureResource):
    
    require = identity.in_group('peon')
    
    def index(self):
        return "restricted_index"
    index = turbogears.expose()(index)

class IdentityRoot(turbogears.controllers.RootController):
    
    def index(self):
        pass
    index = turbogears.expose()(index)
    
    def identity_failed(self):
        return 'identity_failed'
    
    #@turbogears.expose()
    #@identity.require(identity.not_anonymous())
    def logged_in_only(self):
        return 'logged_in_only'
    logged_in_only = turbogears.expose()(logged_in_only)
    logged_in_only = identity.require(identity.not_anonymous())(logged_in_only)
    
    #@turbogears.expose()
    #@identity.require(identity.in_group('peon'))
    def in_peon_group(self):
        return 'in_peon_group'
    in_peon_group = turbogears.expose()(in_peon_group)
    in_peon_group = identity.require(identity.in_group('peon'))(in_peon_group)
    
    def test_exposed_require(self):
        if not hasattr(self.in_peon_group, '_require'):
            return 'no _require attr'
        if not isinstance(self.in_peon_group._require, identity.in_group):
            return 'not correct class'
        if 'peon' != self.in_peon_group._require.group_name:
            return 'not correct group name'
        return '_require is exposed'
    test_exposed_require= turbogears.expose()(test_exposed_require)
    
    def in_admin_group(self):
        return 'in_admin_group'
    in_admin_group = turbogears.expose()(in_admin_group)
    in_admin_group = identity.require(identity.in_group('admin'))(in_admin_group)
    
    def has_chopper_permission(self):
        return 'has_chopper_permission'
    has_chopper_permission = turbogears.expose()(has_chopper_permission)
    has_chopper_permission = identity.require(identity.has_permission('chops_wood'))(has_chopper_permission)
    
    def has_boss_permission(self):
        return "has_boss_permission"
    has_boss_permission = turbogears.expose()(has_boss_permission)
    has_boss_permission = identity.require(identity.has_permission('bosses_people'))(has_boss_permission)
    
    def user_email(self):
        return identity.current.user.email_address
    user_email = turbogears.expose()(user_email)
    user_email = identity.require(identity.not_anonymous())(user_email)
    
    peon_area = RestrictedArea()
    
    def new_user_setup(self, user_name, password):
        return '%s %s' % (user_name, password)
    new_user_setup = turbogears.expose()(new_user_setup)
    
        
class TestIdentity(unittest.TestCase):
    
    def setUp(self):
        self._original_visit_state = turbogears.config.get('visit.on', False)
        self._original_identity_state = turbogears.config.get('identity.on', False)
        self._original_failure_url = turbogears.config.get('identity.failure_url', None)
        self._original_encrypt = turbogears.config.get('identity.soprovider.encryption_algorithm', None)
        # identity requires visit and a failure_url
        turbogears.config.update({'visit.on': True, 'identity.on': True,
                                'identity.failure_url': '/identity_failed',
                                'identity.soprovider.encryption_algorithm': None})
        cherrypy.root = IdentityRoot()
        
        # a 'dummy' call to initialize the database
        testutil.create_request('/')
        turbogears.startup.stopTurboGears()
        
        self.init_model()
        
    def init_model(self):
        if TG_User.select().count() == 0:
            user = TG_User(user_name='samIam', email_address='samiam@example.com', 
                            display_name='Samuel Amicus', password='secret')
            peon_group = TG_Group(group_name="peon", display_name="Regular Peon")
            admin_group = TG_Group(group_name="admin", display_name="Adiministrator")
            chopper_perm = TG_Permission(permission_name='chops_wood', description="Wood Chopper")
            boss_perm = TG_Permission(permission_name='bosses_people', description="Benevolent Dictator")

            peon_group.addTG_Permission(chopper_perm)
            admin_group.addTG_Permission(boss_perm)
            user.addTG_Group(peon_group)
        
    def test_user_password_parameters(self):
        "Controller can receive user_name and password parameters."
        testutil.create_request('/new_user_setup?user_name=test&password=pw')
        firstline = cherrypy.response.body[0]
        assert 'test pw' in firstline, firstline
    
    def test_user_exists(self):
        u = TG_User.by_user_name('samIam')
        assert u.email_address == 'samiam@example.com'
        
    def test_user_password(self):
        "Test if we can set a user password (no encryption algorithm)"
        hub.begin()
        u = TG_User.by_user_name('samIam')
        u.password='password'
        u.sync()
        assert u.password=='password'
        hub.rollback()
        hub.end()
        
    def test_user_password_hashed_sha(self):
        "Test if a sha hashed password is stored in the database."
        turbogears.config.update({'identity.soprovider.encryption_algorithm':'sha1'})
        # force new config values to load
        turbogears.startup.startTurboGears()
        testutil.create_request('/')
        hub.begin()
        u = TG_User.by_user_name('samIam')
        u.password='password'
        u.sync()
        assert u.password =='5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8'
        hub.rollback()
        hub.end()
        turbogears.startup.stopTurboGears()
        
    def test_user_password_hashed_md5(self):
        "Test if a sha hashed password is stored in the database."
        turbogears.config.update({'identity.soprovider.encryption_algorithm':'md5'})
        # force new config values to load
        turbogears.startup.startTurboGears()
        testutil.create_request('/')
        hub.begin()
        u = TG_User.by_user_name('samIam')
        u.password='password'
        u.sync()
        assert u.password =='5f4dcc3b5aa765d61d8327deb882cf99'
        hub.rollback()
        hub.end()
        turbogears.startup.stopTurboGears()
        
    def test_user_password_raw(self):
        "Test that we can store raw values in the password field (without being hashed)."
        turbogears.config.update({'identity.soprovider.encryption_algorithm':'sha1'})
        # force new config values to load
        turbogears.startup.startTurboGears()
        testutil.create_request('/')
        hub.begin()
        u = TG_User.by_user_name('samIam')
        u.set_password_raw('password')
        u.sync()
        assert u.password =='password'
        hub.rollback()
        hub.end()
        turbogears.startup.stopTurboGears()
        
        
    def test_anonymous_browsing(self):
        "Test if we can show up anonymously."
        testutil.create_request('/')
        assert identity.current.anonymous
        
    def test_deny_anonymous(self):
        "Test that we have secured an url from anonymous users."
        testutil.create_request('/logged_in_only')
        firstline = cherrypy.response.body[0]
        assert 'identity_failed' in firstline, firstline
        
    def test_deny_anonymous_viewable(self):
        "Test that a logged in user can see an resource blocked from anonymous users."
        testutil.create_request('/logged_in_only?user_name=samIam&password=secret&login=Login')
        firstline = cherrypy.response.body[0]
        assert 'logged_in_only' in firstline, firstline
        
    def test_require_group(self):
        "Test that a anonymous user"
        testutil.create_request('/in_peon_group')
        firstline = cherrypy.response.body[0]
        assert 'identity_failed' in firstline, firstline
    
    def test_require_expose_required_permission(self):
        '''
        Test that the decorator exposes the correct permissions via _require
        attribute on the actual method.
        '''
        testutil.create_request('/test_exposed_require')
        firstline= cherrypy.response.body[0]
        assert 'require is exposed' in firstline, firstline
        
    def test_require_group_viewable(self):
        "Test that a user with proper group membership can see a restricted url."
        testutil.create_request('/in_peon_group?user_name=samIam&password=secret&login=Login')
        firstline = cherrypy.response.body[0]
        assert 'in_peon_group' in firstline, firstline
        
    def test_user_not_in_right_group(self):
        "Test that a user is denied access if they aren't in the right group."
        testutil.create_request('/in_admin_group?user_name=samIam&password=secret&login=Login')
        firstline = cherrypy.response.body[0]
        assert 'identity_failed' in firstline, firstline
        
    def test_require_permission(self):
        "Test that an anonymous user is denied access to a permission restricted url."
        testutil.create_request('/has_chopper_permission')
        firstline = cherrypy.response.body[0]
        assert 'identity_failed' in firstline, firstline
        
    def test_require_permission_viewable(self):
        "Test that a user with proper permissions can see a restricted url."
        testutil.create_request('/has_chopper_permission?user_name=samIam&password=secret&login=Login')
        firstline = cherrypy.response.body[0]
        assert 'has_chopper_permission' in firstline, firstline
        
    def test_user_lacks_permission(self):
        "Test that a user is denied acces if they don't have the proper permission."
        testutil.create_request('/has_boss_permission?user_name=samIam&password=secret&login=Login')
        firstline = cherrypy.response.body[0]
        assert 'identity_failed' in firstline, firstline
        
    def test_user_info_available(self):
        "Test that we can see user information inside our controller."
        testutil.create_request('/user_email?user_name=samIam&password=secret&login=Login')
        firstline = cherrypy.response.body[0]
        assert 'samiam@example.com' in firstline, firstline
        
    def test_bad_login(self):
        "Test that we are denied access if we provide a bad login."
        testutil.create_request('/logged_in_only?user_name=samIam&password=wrong&login=Login')
        firstline = cherrypy.response.body[0]
        assert 'identity_failed' in firstline, firstline
        
    def test_restricted_subdirectory(self):
        "Test that we can restrict access to a whole subdirectory."
        testutil.create_request('/peon_area/index')
        firstline = cherrypy.response.body[0]
        assert 'identity_failed' in firstline, firstline
        
    def test_restricted_subdirectory_viewable(self):
        "Test that we can access a restricted subdirectory if we have proper credentials."
        testutil.create_request('/peon_area/index?user_name=samIam&password=secret&login=Login')
        firstline = cherrypy.response.body[0]
        assert 'restricted_index' in firstline, firstline
          
    def tearDown(self):
        turbogears.config.update({'visit.on': self._original_visit_state, 
                                'identity.on': self._original_identity_state,
                                'identity.failure_url': self._original_failure_url,
                                'identity.soprovider.encryption_algorithm':self._original_encrypt}) 
                                
class TestTGUser(testutil.DBTest):
    model = TG_User
    
    def setUp(self):
        testutil.DBTest.setUp(self)
        self._id_state = turbogears.config.get('identity.on', False)
        turbogears.config.update({'identity.on':False})
        turbogears.startup.startTurboGears()
        try:
            self._provider = cherrypy.request.identityProvider
        except AttributeError:
            self._provider= None
        cherrypy.request.identityProvider = None
    
    def test_create_user(self):
        "User can be created outside of a running identity provider."
        
        u = TG_User(user_name='testcase', email_address='testcase@example.com', 
                        display_name='Test Me', password='test')
        assert u.password=='test', u.password 
                    
    def tearDown(self):
        testutil.DBTest.tearDown(self)
        turbogears.startup.stopTurboGears()
        turbogears.config.update({'identity.on': self._id_state})
        cherrypy.request.identityProvider = self._provider
        
    
      
