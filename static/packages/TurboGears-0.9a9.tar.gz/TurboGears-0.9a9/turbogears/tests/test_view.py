# -*- coding: utf-8 -*- 

from turbogears import view, config
import unittest

class TestView(unittest.TestCase):

    def test_UnicodeValueAppearingInATemplateIsFine(self):
        ustr = u"micro-eXtreme Programming ( µ XP): Embedding XP Within Standard Projects"
        info = dict(someval=ustr)
        val = view.render(info, template="turbogears.tests.simple")
        self.failUnless(u"Paging all " + ustr in val.decode("utf-8"))

    def test_templateRetrievalByPath(self):
        config.update({'server.environment' : 'development'})
        from turbokid import kidsupport
        ks = kidsupport.KidSupport()
        cls = ks.load_template("turbogears.tests.simple")
        assert cls is not None
        t = cls()
        t.someval = "hello"
        filled = str(t)
        assert "groovy" in filled
        assert "html" in filled
        
        # the following import should not fail, if everything is working correctly.
        import turbogears.tests.simple
