from turbogears.testutil import *

from warnings import warn
warn("turbogears.tests.util has been replaced by turbogears.testutil",
    DeprecationWarning, 2)