:mod:`pylons.decorators.secure` -- Secure Decorators
====================================================

.. automodule:: pylons.decorators.secure

Module Contents
---------------

.. autofunction:: authenticate_form
.. autofunction:: https
