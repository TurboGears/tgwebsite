:mod:`tg.flash` -- Flash
========================================

.. automodule:: tg.flash
  :members: