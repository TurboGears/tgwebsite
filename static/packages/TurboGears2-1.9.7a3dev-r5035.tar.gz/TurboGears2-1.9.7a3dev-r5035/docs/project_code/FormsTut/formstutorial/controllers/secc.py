"""Test Secure Controller"""

# This controller is only used when you activate identity. You can safely remove
# this file from your project.
