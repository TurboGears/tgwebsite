

Existing ToscaWidgets Packages
==============================

tw.forms
--------
A nice coupling of ToscaWidgets form fields with FormEncode validation.

tw.recaptcha
------------
ReCaptcha packaged as a ToscaWidget

tw.rating
---------
Ajax star rating system

tw.mootools
-----------
a MooTools library for TW

tw.jquery
---------
includes:
 * ActiveForm (ajax form)
 * AutoCompleteField
 * flot
