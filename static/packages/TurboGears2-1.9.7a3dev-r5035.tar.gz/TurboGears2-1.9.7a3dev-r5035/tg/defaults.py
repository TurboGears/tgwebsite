"""TurboGears2 helpers for setting up your application enviroment

The intention of this module is to provie some helpers that setup sane defaults 
for TG2 applications.  The goal is to make the config files smaller, simpler and easier to read. 
"""

from pylons import config
from routes import Mapper

def make_default_route_map():
    """Create, configure and return the routes Mapper"""
    
    import warnings
    warnings.warn("tg.defaults is depricated overide setup_routes on base_config object instead")
    
    map = Mapper(directory=config['pylons.paths']['controllers'],
                always_scan=config['debug'])
    
    # Setup a default route for the error controller:
    map.connect('error/:action/:id', controller='error')
    
    ## Replace the next line with your overides.   Overides should generally come
    ## bevore the default route defined below
    # map.connect('overide/url/here', controller='mycontrller', action='send_stuff')
    
    # This route connects your root controller, it should be after
    # more specific routes since the wildcard will pick up everything...
    map.connect('*url', controller='root', action='routes_placeholder')

    return map
