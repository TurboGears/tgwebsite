*****************************
The :mod:`repoze.what` Manual
*****************************

:Author: Gustavo Narea.
:Version: |version|

Below are the contents for the :mod:`repoze.what` manual:

.. toctree::
    :maxdepth: 3

    GettingStarted
    Predicates/index
    ManagingSources
    Plugins/index
    InnerWorkings
