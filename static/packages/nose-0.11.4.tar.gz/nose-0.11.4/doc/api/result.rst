.. automodule :: nose.result
   :members: