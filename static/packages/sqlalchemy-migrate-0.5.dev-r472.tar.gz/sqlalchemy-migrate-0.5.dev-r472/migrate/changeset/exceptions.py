

class Error(Exception):
    pass

class NotSupportedError(Error):
    pass

class InvalidConstraintError(Error):
    pass

