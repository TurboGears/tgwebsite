"""This package contains classes, functions, objects and packages contributed
   by Cheetah users.  They are not used by Cheetah itself.  There is no
   guarantee that this directory will be included in Cheetah releases, that
   these objects will remain here forever, or that they will remain
   backward-compatible.
"""

# vim: shiftwidth=5 tabstop=5 expandtab
