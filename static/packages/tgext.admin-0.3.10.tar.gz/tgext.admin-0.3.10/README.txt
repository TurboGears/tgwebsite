Introduction
============

Changelog
===========

0.3
----
Lookup now uses ProviderSelector, for better mongo support

0.2.6
-----
Bugfix release.  Support for _method fields in TG2.1

0.2.5
------
* Addition of defaultCrudRestController to
CRCConfig allows one to customize the controller
that the admin uses.

* Fixes tgadminconfig to override the Password properly for Users
