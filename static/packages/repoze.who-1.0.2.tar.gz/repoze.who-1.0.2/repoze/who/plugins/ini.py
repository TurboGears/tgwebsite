from repoze.pam.interfaces import IMetadataProvider
from zope.interface import implements
from ConfigParser import ConfigParser
