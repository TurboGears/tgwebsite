*****************************
The :mod:`repoze.what` Manual
*****************************

:Author: Gustavo Narea.
:Version: |version|

Below are the contents for the :mod:`repoze.what` manual:

.. toctree::
    :maxdepth: 2

    GettingStarted
    Predicates
    ManagingSources
    Plugins/index
    InnerWorkings
