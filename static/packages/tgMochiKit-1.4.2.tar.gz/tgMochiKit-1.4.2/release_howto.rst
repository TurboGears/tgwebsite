
For each python, do::

  pythonX.X setup.py egg_info -RDb "" sdist bdist_egg -p "" register upload