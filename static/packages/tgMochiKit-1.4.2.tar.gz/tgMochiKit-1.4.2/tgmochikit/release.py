# Release information about tgMochikit

version = "1.4.2"

description = "MochiKit packaged as TurboGears widgets."
author = "Diez B. Roggisch"
email = "deets@web.de"
copyright = "Copyright 2008"

url = "http://docs.turbogears.org/tgMochiKit"
download_url = "http://pypi.python.org/pypi/tgMochiKit"
license = "AFL/MIT"
