:mod:`pylons.controllers.util` -- Controller Utility functions
======================================================================

.. automodule:: pylons.controllers.util

Module Contents
---------------

.. autoclass:: Request
    :members:
    :undoc-members:
    :show-inheritance:
.. autoclass:: Response
    :members:
    :undoc-members:
    :show-inheritance:
.. autofunction:: abort
.. autofunction:: etag_cache
.. autofunction:: forward
.. autofunction:: redirect
.. autofunction:: redirect_to
