:mod:`pylons.controllers.core` -- WSGIController Class
======================================================

.. automodule:: pylons.controllers.core

Module Contents
---------------

.. autoclass:: WSGIController
    :members: _perform_call, _inspect_call, _get_method_args, _dispatch_call, __call__
