.. _tutorials:

Pylons Tutorials
================

A small collection of relevant tutorials.

.. toctree::
    :maxdepth: 2

    flickr_search_tutorial
    quickwiki_tutorial
    understanding_unicode
