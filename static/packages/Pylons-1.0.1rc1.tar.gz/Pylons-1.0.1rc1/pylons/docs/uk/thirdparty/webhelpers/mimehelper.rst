:mod:`~webhelpers.mimehelper` -- MIMEtypes helper
=================================================

:mod:`webhelpers.mimehelper`
----------------------------

.. currentmodule:: webhelpers.mimehelper

.. autoclass:: MIMETypes
    :members:

