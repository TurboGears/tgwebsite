:mod:`~webhelpers.date` -- Date helpers
=======================================

:mod:`webhelpers.date`
----------------------

.. currentmodule:: webhelpers.date

.. autofunction:: distance_of_time_in_words
.. autofunction:: time_ago_in_words

