:mod:`webhelpers.pylonslib` -- ``flash`` alert div helpers
===========================================================

:mod:`webhelpers.pylonslib`
---------------------------

.. currentmodule:: webhelpers.pylonslib

.. autoclass:: Flash
    :members:

