:mod:`~webhelpers.pagination` -- WebHelpers Pagination *(part deprecated)*
==========================================================================

:mod:`~webhelpers.pagination.links`
-----------------------------------

.. currentmodule:: webhelpers.pagination.links

.. autofunction:: pagelist

:mod:`~webhelpers.pagination.orm`
---------------------------------

.. currentmodule:: webhelpers.pagination.orm

.. warning:: Deprecated: Use ``webhelpers.paginate``

