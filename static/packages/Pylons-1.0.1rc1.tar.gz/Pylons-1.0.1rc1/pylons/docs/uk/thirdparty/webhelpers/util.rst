:mod:`~webhelpers.util` -- Utilities
====================================

:mod:`webhelpers.util`
----------------------

.. currentmodule:: webhelpers.util

.. autofunction:: html_escape
.. autofunction:: iri_to_uri
.. autoclass:: Partial
    :members:
.. autoclass:: SimplerXMLGenerator
    :members:
.. autoclass:: UnicodeMultiDict
    :members:


