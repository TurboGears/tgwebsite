:mod:`~webhelpers.htmlgen` *(deprecated)*
=========================================


:mod:`webhelpers.htmlgen`
-------------------------

.. currentmodule:: webhelpers.htmlgen

.. warning:: ``webhelpers/htmlgen.py`` is deprecated, use ``webhelpers.html`` instead.


