:mod:`~webhelpers.hinclude` *(deprecated)*
==========================================

:mod:`webhelpers.hinclude`
--------------------------


.. warning:: ``webhelpers/hinclude.py`` is deprecated and is too trivial to port, DIY.
