:mod:`webhelpers.commands.compress_resources` -- *(deprecated)*
===============================================================

.. currentmodule:: webhelpers.commands.compress_resources

.. warning:: DEPRECATED!! BUGGY!! Do not use in new projects.

.. autoclass:: compress_resources
    :members:
