:mod:`~webhelpers.constants` -- Useful constants (Geo-lists)
============================================================

:mod:`webhelpers.constants`
----------------------------

.. automodule:: webhelpers.constants

.. currentmodule:: webhelpers.constants

.. autofunction:: uk_counties
.. autofunction:: country_codes
.. autofunction:: us_states
.. autofunction:: us_territories
.. autofunction:: canada_provinces

