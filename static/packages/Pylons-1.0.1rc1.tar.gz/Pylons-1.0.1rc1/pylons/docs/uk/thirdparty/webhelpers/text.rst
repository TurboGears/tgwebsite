:mod:`~webhelpers.text` -- Text helpers
=======================================

:mod:`webhelpers.text`
----------------------

.. currentmodule:: webhelpers.text

.. autofunction:: truncate
.. autofunction:: excerpt
.. autofunction:: plural
.. autofunction:: chop_at
.. autofunction:: lchop
.. autofunction:: rchop
.. autofunction:: strip_leading_whitespace
.. autofunction:: wrap_paragraphs

