# TurboJson package

from turbojson.jsonsupport import JsonSupport

__all__ = ['JsonSupport']
