import logging

from testapp.lib.base import *
import mapfish.controllers.security

log = logging.getLogger(__name__)

class SecurityController(mapfish.controllers.security.SecurityController):
    pass
