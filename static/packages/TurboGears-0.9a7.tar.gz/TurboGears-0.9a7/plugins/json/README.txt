TurboJson
============

This package provides a template engine plugin, allowing you
to easily use Json with TurboGears, Buffet or other systems
that support python.templating.engines.


For information on using a template engine plugin with TurboGears
or writing a template engine plugin, go here:

http://www.turbogears.org/docs/plugins/template.html
