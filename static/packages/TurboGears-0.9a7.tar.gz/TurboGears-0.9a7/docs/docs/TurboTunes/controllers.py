import turbogears
from turbogears import controllers
from turbogears.catwalk import CatWalk
import model

class Root(controllers.Root):
    catwalk = CatWalk(model)

    @turbogears.expose()
    def songs(self,album):
      a = model.Album.get(album)
      return dict(rows= [[song.name, song.album.artist.name, song.album.name] for song in a.songs]) 

    @turbogears.expose()
    def albums(self,artist):
      a = model.Artist.get(artist)
      return dict(selectID='albums',options = [{'label':album.name,'value':album.id} for album in a.albums])

    @turbogears.expose()
    def artists(self,genre):
      g = model.Genre.get(genre)
      return dict(selectID='artists',options = [{'label':artist.name,'value':artist.id} for artist in g.artists])

    @turbogears.expose()
    def genres(self):
      return dict(selectID='genres',options = [{'label':genre.name,'value':genre.id}  for genre in model.Genre.select()])
        
    @turbogears.expose(html="turboTunes.templates.tunes")
    def index(self):
      return dict()
