from sqlobject import *
from turbogears.database import PackageHub

hub = PackageHub("turboTunes")
__connection__ = hub

class Genre(SQLObject):
  name = StringCol(length=200)
  artists = RelatedJoin('Artist')

class Artist(SQLObject):
  name = StringCol(length=200)
  genres = RelatedJoin('Genre')
  albums = MultipleJoin('Album')

class Album(SQLObject):
  name = StringCol(length=200)
  artist = ForeignKey('Artist')
  songs = MultipleJoin('Song')

class Song(SQLObject):
  name = StringCol(length=200)
  album = ForeignKey('Album')

Genre.createTable(ifNotExists=True)
Artist.createTable(ifNotExists=True)
Album.createTable(ifNotExists=True)
Song.createTable(ifNotExists=True)
