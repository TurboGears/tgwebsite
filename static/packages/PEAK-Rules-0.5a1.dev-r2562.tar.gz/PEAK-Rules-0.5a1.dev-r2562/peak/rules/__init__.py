"""The PEAK Rules Framework"""

from peak.rules.core import *

