class MingException(Exception): pass
class MongoGone(MingException): pass
class MingConfigError(MingException): pass
    
