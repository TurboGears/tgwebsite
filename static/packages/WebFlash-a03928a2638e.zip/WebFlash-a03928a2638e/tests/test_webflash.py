import os
import unittest
from webob import Request, Response, exc
from webtest import TestApp
from webflash import Flash

here = os.path.abspath(os.path.dirname(__file__))

template = """
<html>
<head>
    <title>WebFlash Test App</title>
    <style>
        #flash {
            display: none;
            width: 100%%
            height: 50px;
        }
        #flash .ok {
            background: green;
        }
        #flash .warning {
            background: yellow;
        }
        #flash .error {
            background: red;
        }
    </style>
</head>

<body>
    %(flash)s
    <div id="flash"></div>
    <form action="" method="post">
        <label>(w. redirect) Message:
            <input type="text" name="message" />
        </label>
        <label>Status:
            <select name="status">
                <option value="ok">Ok</option>
                <option value="warning">Warning</option>
                <option value="error">Error</option>
            </select>
        </label>
        <label>(w. redirect) Delay:
            <input type="text" name="delay" />
        </label>
        <input type="submit" value="Try it!" />
    </form>
    <form action="" method="get">
        <label>(wo. redirect) Message:
            <input type="text" name="message" />
         </label>
        <label>Status:
            <select name="status">
                <option value="ok">Ok</option>
                <option value="warning">Warning</option>
                <option value="error">Error</option>
            </select>
        </label>
        <label>(w. redirect) Delay:
            <input type="text" name="delay" />
        </label>
        <input type="submit" value="Try it!" />
    </form>
    <h3>Tests</h3>
    <div id="test-console">
    </div>
    <script type="text/javascript">%(tests)s</script>
</body>
</html>
"""

def make_app(flash):
    def application(environ, start_response):
        req = Request(environ)
        message = req.params.get('message')
        status = req.params.get('status')
        delay = req.params.get('delay')
        if delay:
            delay = int(delay)
        else:
            delay = None
        if req.method.upper() == "POST":
            # Redirect but signal GET handler not to set flash or else
            # it will overrite the flash we're setting now
            resp = exc.HTTPSeeOther(
                location=req.script_name + req.path_info
                )
            flash(message, status, delay=delay, response=resp)
        else:
            RST_js = open(os.path.join(here, 'RST.js')).read()
            tests = open(os.path.join(here, 'test.js')).read()
            resp = Response(template % {
                'flash': flash.render("flash"),
                'tests': RST_js + tests
                })
            if 'message' in req.GET:
                # Test display on flash when no redirect occurs
                flash(message, status, delay=delay, response=resp)
        # Set a sentinel to ensure JS code doesn't delete other cookies
        resp.set_cookie('sentinel', 'I should be there')
        return resp(environ, start_response)
    return application



class TestFlashApp(unittest.TestCase):
    def makeOne(self, flash=Flash()):
        return TestApp(make_app(flash))

    def test_cookie_not_set_if_no_flash(self):
        app = self.makeOne()
        resp = app.get('/')
        self.failUnless('webflash' not in resp.cookies_set)

    def test_cookie_set_if_flash_on_post(self):
        app = self.makeOne()
        resp = app.post('/', dict(message='foo'))
        self.failUnless('webflash' in resp.cookies_set)

    def test_cookie_set_if_flash_on_get(self):
        app = self.makeOne()
        resp = app.get('/', dict(message='foo'))
        self.failUnless('webflash' in resp.cookies_set)

if __name__ == '__main__':
    from wsgiref import simple_server
    import webbrowser
    flash = Flash()
    app = make_app(flash)
    s = simple_server.make_server('', 8080, app)
    if 'NOBROWSER' not in os.environ:
        webbrowser.open('http://127.0.0.1:8080')
    try:
        s.serve_forever()
    except (KeyboardInterrupt, SystemExit):
        pass

