window.setTimeout(function() {
    // poor mans addLoadEvent
    var tests = {
        sentinelInCookie: function() {
            test.assert(document.cookie.indexOf('sentinel') > -1,
                        "Sentinel cookie not found");
        }

    };
    if (window.location.href.indexOf('message')>-1) {
        tests.flashInDom = function() {
            var flash_container = document.getElementById('flash');
            test.assert(flash_container.firstChild !== null,
                        "No flash message present"
                    )
        }
    } else if (document.getElementById('flash').firstChild === null) {
        // do a redirect in to run test
        setTimeout(function() {
            window.location = window.location.href + '?message=testing'
        }, 500);
    }
    test(tests);
}, 1000);
