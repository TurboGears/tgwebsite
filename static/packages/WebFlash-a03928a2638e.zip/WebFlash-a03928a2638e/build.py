import os
import pkg_resources
import subprocess
from webflash import Flash

here = os.path.abspath(os.path.dirname(__file__))
YUI_COMPRESSOR = os.path.join(here, 'yuicompressor-2.4.2.jar')

def main(argv=None):
    src = Flash(debug=True).js_path
    dest = Flash(debug=False).js_path
    subprocess.check_call(['java', '-jar', YUI_COMPRESSOR, '-o', dest, src])

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv[1:]))
