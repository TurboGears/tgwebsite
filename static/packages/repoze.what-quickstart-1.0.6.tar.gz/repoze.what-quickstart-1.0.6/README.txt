*********************************
The repoze.what Quickstart plugin
*********************************

This is an extras plugin for repoze.what.

This plugin allows you to take advantage of a rather simple, and usual, 
authentication and authorization setup, in which the users' data, the groups 
and the permissions used in the application are all stored in a SQLAlchemy 
or Elixir-managed database.

Put simply, it configures repoze.who and repoze.what in one go so that you 
can have an authentication and authorization system working quickly -- hence 
the name.
