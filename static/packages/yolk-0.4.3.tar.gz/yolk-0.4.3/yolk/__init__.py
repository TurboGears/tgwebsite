
"""

__init__.py

Author: Rob Cakebread <cakebread at gmail>

License  : BSD

"""

__docformat__ = 'restructuredtext'
__version__ = '0.4.3'


