({
		previousMessage: "以前の選択項目",
		nextMessage: "追加の選択項目"
})
