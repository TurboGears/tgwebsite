({
	fontSize: "Size",
	fontName: "Font",
	formatBlock: "Format",

	serif: "serif",
	"sans-serif": "sans-serif",
	monospace: "monospace",
	cursive: "cursive",
	fantasy: "fantasy",

	p: "Paragraph",
	h1: "Heading",
	h2: "Subheading",
	h3: "Sub-subheading",
	pre: "Pre-formatted",

	1: "xx-small",
	2: "x-small",
	3: "small",
	4: "medium",
	5: "large",
	6: "x-large",
	7: "xx-large"
})