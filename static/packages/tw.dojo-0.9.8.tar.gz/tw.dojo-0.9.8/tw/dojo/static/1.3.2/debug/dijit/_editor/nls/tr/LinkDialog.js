({
	createLinkTitle: "Bağlantı Özellikleri",
	insertImageTitle: "Resim Özellikleri",
	url: "URL:",
	text: "Açıklama:",
	set: "Ayarla"
})
