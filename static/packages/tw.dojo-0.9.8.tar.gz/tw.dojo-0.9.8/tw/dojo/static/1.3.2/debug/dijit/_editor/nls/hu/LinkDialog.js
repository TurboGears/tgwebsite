({
	createLinkTitle: "Hivatkozás tulajdonságai",
	insertImageTitle: "Kép tulajdonságai",
	url: "URL:",
	text: "Leírás:",
	set: "Beállítás"
})
