********************************
The repoze.who SQLAlchemy plugin
********************************

This plugin provides one repoze.who authenticator and one metadata provider
which works with SQLAlchemy or Elixir-based models.
