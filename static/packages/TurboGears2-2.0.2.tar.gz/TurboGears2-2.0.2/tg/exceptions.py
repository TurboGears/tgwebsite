"""http exceptions for TurboGears

TurboGears http exceptions are inherited from paste httpexceptions
"""
from webob.exc import *
