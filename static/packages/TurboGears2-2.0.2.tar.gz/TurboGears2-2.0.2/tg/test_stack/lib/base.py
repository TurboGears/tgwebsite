"""Pylons requires that packages have a lib.base and lib.helpers 


So we've added on here so we can run tests in the context of the tg 
package itself, pylons will likely remove this restriction before 1.0 
and this module can then be removed. 

"""