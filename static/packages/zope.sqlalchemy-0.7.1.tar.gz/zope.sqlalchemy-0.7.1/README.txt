See src/zope/sqlalchemy/README.txt
