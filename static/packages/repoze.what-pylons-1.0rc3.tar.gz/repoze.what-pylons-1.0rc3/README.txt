*********************************************
The repoze.what plugin for Pylons integration
*********************************************

This is an extras plugin for repoze.what which provides optional and handy 
utilities for Pylons applications using this authorization framework.

Some of the features of the plugin include:

* The utilities are ready to use: There's nothing additional to be
  configured before using.
* 100% documented. Each component is documented along with code samples.
* The test suite has a coverage of 100% and it will never decrease -- if
  it ever does, report it as a bug!
* TurboGears 2 is officially supported as well.
