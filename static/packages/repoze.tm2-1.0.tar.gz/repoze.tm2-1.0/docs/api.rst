:mod:`repoze.tm`
----------------

.. automodule:: repoze.tm

.. autofunction:: default_commit_veto

.. autoclass:: TM

.. autoclass:: AfterEnd

.. attribute:: after_end


