============
Transactions
============

This package contains a generic transaction implementation for Python. It is
mainly used by the ZODB.

See http://www.zodb.org/zodbbook/transactions.html for narrative
documentation on its usage.

