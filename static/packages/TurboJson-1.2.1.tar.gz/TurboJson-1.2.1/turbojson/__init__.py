from turbojson import jsonsupport

JsonSupport = jsonsupport.JsonSupport

__all__ = ["JsonSupport"]
