"""
   This package provides functionality to create and manage
   repositories of database schema changesets and to apply these
   changesets to databases.
"""
