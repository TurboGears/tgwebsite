GenshiTest

This is a TurboGears (http://www.turbogears.org) project. It can be
started by running the start-markuptest.py script.
