class DummyEntity:pass
