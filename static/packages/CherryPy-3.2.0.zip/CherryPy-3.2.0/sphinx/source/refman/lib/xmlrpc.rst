**************************
:mod:`cherrypy.lib.xmlrpc`
**************************

.. automodule:: cherrypy.lib.xmlrpc

Functions
=========

.. autofunction:: process_body

.. autofunction:: patched_path

.. autofunction:: respond

.. autofunction:: on_error

