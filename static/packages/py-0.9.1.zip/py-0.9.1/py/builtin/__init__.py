""" backports and additions of builtins """

