""" some nice, slightly magic APIs """
