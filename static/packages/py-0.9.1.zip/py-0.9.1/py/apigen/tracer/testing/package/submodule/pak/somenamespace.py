def foo(x):
    return x + 1

def bar(x):
    return x + 2
