class cls(object):
    def __init__(self, x):
        self.x = x

def one(x):
    return x+3

def nottwo():
    pass

