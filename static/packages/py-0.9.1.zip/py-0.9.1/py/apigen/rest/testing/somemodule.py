class SomeClass(object):
    """Some class definition"""
    
    def __init__(self, a):
        self.a = a
    
    def method(self, a, b, c):
        """method docstring"""
        return a + b + c

