from somemodule import SomeClass

class SomeSubClass(SomeClass):
    """Some subclass definition"""

def fun(a, b, c):
    """Some docstring
    
        Let's make it span a couple of lines to be interesting...

        Note:

         * rest
         * should
         * be
         * supported
         * or
         * ignored...
    """
    return "d"

