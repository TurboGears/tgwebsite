""" small and mean xml/html generation """

