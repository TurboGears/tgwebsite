import py
from py.__.misc._dist import setup
setup(py) 
