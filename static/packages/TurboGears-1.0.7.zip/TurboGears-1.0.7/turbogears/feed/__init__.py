from turbogears.feed import feed
FeedController = feed.FeedController
