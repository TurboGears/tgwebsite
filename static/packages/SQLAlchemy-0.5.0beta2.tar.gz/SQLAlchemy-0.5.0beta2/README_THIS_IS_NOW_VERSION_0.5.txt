Trunk of SQLAlchemy is now on the 0.5 version.  This version 
removes many things which were deprecated in 0.4 and therefore 
is not backwards compatible with all 0.4 appliactions.

A work in progress describing the changes from 0.4 is at:

    http://www.sqlalchemy.org/trac/wiki/05Migration

IMPORTANT: some file names have changed in this branch.  Remove all existing *.pyc files before using !

To continue working with the current development revision of 
version 0.4, switch this working copy to the 0.4 maintenance branch:

    svn switch http://svn.sqlalchemy.org/sqlalchemy/branches/rel_0_4


