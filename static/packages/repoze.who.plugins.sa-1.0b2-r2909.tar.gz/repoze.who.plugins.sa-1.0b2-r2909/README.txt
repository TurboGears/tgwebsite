***************************************
The :mod:`repoze.who` SQLAlchemy plugin
***************************************

This plugin provides one repoze.who authenticator which works with SQLAlchemy
or Elixir-based models.
