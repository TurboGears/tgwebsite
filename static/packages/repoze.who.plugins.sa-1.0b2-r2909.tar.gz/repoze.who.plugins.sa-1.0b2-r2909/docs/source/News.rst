*************************************
:mod:`repoze.who.plugins.sa` releases
*************************************

This document describes the releases of :mod:`repoze.who.plugins.sa`.


.. _repoze.who.plugins.sa-1.0b2:

:mod:`repoze.who.plugins.sa` 1.0b2 (2008-12-18)
===============================================

Renamed :mod:`repoze.who.plugins.sqlalchemy` to :mod:`repoze.who.plugins.sa`
due to problems with the namespace.


.. _repoze.who.plugins.sqlalchemy-1.0b1:

:mod:`repoze.who.plugins.sqlalchemy` 1.0b1 (2008-12-18)
=======================================================

Initial release.
