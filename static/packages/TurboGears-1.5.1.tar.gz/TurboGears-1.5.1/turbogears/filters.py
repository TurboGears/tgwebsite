"""Package collecting various request filters."""

raise ImportError("The filters have been replaced by hooks in TurboGears 1.5")
