Zope3 Internationalization Support
==================================

This package implements several APIs related to internationalization and
localization.

* Locale objects for all locales maintained by the ICU project.

* Gettext-based message catalogs for message strings.

* Locale discovery for Web-based requests.
