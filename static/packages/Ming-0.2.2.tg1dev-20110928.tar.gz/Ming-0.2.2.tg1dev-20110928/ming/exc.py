class MingException(Exception): pass
class MongoGone(MingException): pass
