This example shows how to transform some HTML input, while adding
elements such as headers, and using <em>/<strong> instead of <i>/<b>.
The output is that a proper XTHML document.
