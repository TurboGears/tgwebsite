__DOJO_VERSION__ = '1.4.1'
__DEFAULT_LINK_IS_EXTERNAL__ = False
__DOJO_URL_BASE__ = 'http://ajax.googleapis.com/ajax/libs/dojo/1.3/'
__DEFAULT_PREFIX__ = 'min'