from turbogears import widgets
from turbogears import validators
from tgfastdata.datawidgets import DataCheckBoxList, DataSelectField
import dispatch
import re
from sqlobject import col, joins, classregistry

def column_widget(column):
    pass
column_widget = dispatch.generic()(column_widget)

def name2label(name):
    """
    Convert a column name to a Human Readable name.
    """
    # Create label from the name:
    #   1) Convert _ to spaces
    #   2) Convert CamelCase to Camel Case
    #   3) Upcase first character of Each Word
    # Note: I *think* it would be thread-safe to
    #       memoize this thing.
    return ' '.join([s.capitalize() for s in
               re.findall(r'([A-Z][a-z0-9]+|[a-z0-9]+|[A-Z0-9]+)', name)])

def column_parms(column):
    """
    Helper function to convert column attributes to
    parameters needed to initialize a widget.
    """
    parms = { 'name' : column.name }
    if column.title:
        parms['label'] = column.title
    else:
        parms['label'] = name2label(column.name)
    if column.default != col.NoDefault:
        parms['default'] = column.default
    return parms

def column_widget_generic_col(column):
    parms = column_parms(column)
    return widgets.TextField(**parms)
column_widget_generic_col = column_widget.when(
        "isinstance(column, col.SOCol)")(column_widget_generic_col)

def column_widget_int_col(column):
    parms = column_parms(column)
    return widgets.TextField(validator=validators.Int(), **parms)
column_widget_int_col = column_widget.when(
        "isinstance(column, col.SOIntCol)")(column_widget_int_col)

def column_widget_float_col(column):
    parms = column_parms(column)
    return widgets.TextField(validator=validators.Number(), **parms)
column_widget_int_col = column_widget.when(
        "isinstance(column, (col.SOFloatCol))")(column_widget_float_col)
    
def column_widget_string_col(column):
    parms = column_parms(column)
    if column.length:
        return widgets.TextField(**parms)
    else:
        return widgets.TextArea(rows=7, cols=50, **parms)
column_widget_string_col = column_widget.when(
        "isinstance(column, col.SOStringLikeCol)")(column_widget_string_col)

def column_widget_enum_col(column):
    params = column_parms(column)
    params['options'] = [(value, value) for value in column.enumValues ]
    params['validator'] = validators.OneOf(column.enumValues)
    return widgets.SingleSelectField(**params)
column_widget_enum_col = column_widget.when(
        "isinstance(column,col.SOEnumCol)")(column_widget_enum_col)
        
def column_widget_date_col(column):
    parms = column_parms(column)
    return widgets.CalendarDatePicker(**parms)
column_widget_date_col = column_widget.when(
        "isinstance(column,col.SODateCol)")(column_widget_date_col)

def column_widget_datetime_col(column):
    parms = column_parms(column)
    return widgets.CalendarDateTimePicker(**parms)
column_widget_date_col = column_widget.when(
        "isinstance(column,col.SODateTimeCol)")(column_widget_datetime_col)

def column_boolean(column):
    return widgets.CheckBox(column.name)
column_boolean = column_widget.when("isinstance(column, col.SOBoolCol)")(column_boolean)

def column_widget_fkey_col(column):
    parms = column_parms(column)
    parms['name'] = parms['name'][:-2] # strip 'ID' from the end
    fkey_class = classregistry.findClass(column.foreignKey)
    items = fkey_class.select()
    # make options a callable to retrieve fresh data 
    # every time the widget is rendered
    parms['options'] = lambda: [(None, '')] + [(item.id, unicode(item)) for item in items]
    return DataSelectField(**parms)
column_widget_fkey_col = column_widget.when(
        "isinstance(column,col.SOKeyCol)")(column_widget_fkey_col)
def join_widget(join):
    pass
join_widget = dispatch.generic()(join_widget)

def join_parms(join):
    """
    Helper function to convert join attributes to
    parameters needed to initialize a widget.
    """
    parms = { 'name' : join.joinMethodName, 
              'label' : name2label( join.joinMethodName) }
    return parms

def join_widget_related_join(join):
    parms = join_parms(join)
    items = join.otherClass.select()
    # make options a callable to retrieve fresh data 
    # every time the widget is rendered
    parms['options'] = lambda: [(item.id, unicode(item)) for item in items]
    return DataCheckBoxList(**parms)
join_widget_related_col = join_widget.when(
        "isinstance(join,joins.SORelatedJoin)")(join_widget_related_join)

def fields_for(sqlclass, fields=None):
    if fields:
        columnlist = fields
    elif hasattr(sqlclass, "form_order"):
        columnlist = sqlclass.form_order
    else:
        columnlist = sqlclass.sqlmeta.columns
    widgetlist = []
    for column in columnlist:
        widget = None
        if sqlclass.sqlmeta.columns.has_key(column):
            widget = column_widget(sqlclass.sqlmeta.columns[column])
        elif sqlclass.sqlmeta.columns.has_key(column + 'ID'): #key column
            widget = column_widget(sqlclass.sqlmeta.columns[column + 'ID'])
        else:
            for join in sqlclass.sqlmeta.joins:
                if join.joinMethodName == column:
                    widget = join_widget(join)
                    break
        if not widget:
            raise Exception, "Join or column %r not found in class %r" % (column, sqlclass.__name__)
        widgetlist.append(widget)
    return widgetlist

def sqlwidgets(sqlclass, fields=None):
    import warnings
    warnings.warn("Use fields_for() rather than sqlwidgets().", DeprecationWarning, 2)
    return fields_for(sqlclass, fields)
