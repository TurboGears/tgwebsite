def tgsymbols():
    import tgfastdata
    return dict(fastdata=tgfastdata)
