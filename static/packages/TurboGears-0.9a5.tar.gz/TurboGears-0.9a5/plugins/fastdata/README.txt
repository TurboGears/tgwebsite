TurboGears FastData
===================

FastData is an extension to TurboGears which can provide automatic user
interface generation based upon an application's model objects.
