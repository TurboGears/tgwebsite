"""Standard Controllers intended for subclassing by web developers"""
from pylons.controllers.core import WSGIController
from pylons.controllers.xmlrpc import XMLRPCController
