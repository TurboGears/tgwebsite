***************
Zope Interfaces
***************

.. contents::

Interfaces are a mechanism for labeling objects as conforming to a given
API or contract.
