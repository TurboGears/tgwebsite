:mod:`pylons.decorators.cache` -- Cache Decorators
======================================================================

.. automodule:: pylons.decorators.cache

Module Contents
---------------

.. autofunction:: beaker_cache
