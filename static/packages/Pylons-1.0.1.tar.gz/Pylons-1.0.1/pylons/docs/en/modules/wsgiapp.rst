:mod:`pylons.wsgiapp` -- PylonsWSGI App Creator
===============================================

.. automodule:: pylons.wsgiapp

Module Contents
---------------

.. autoclass:: PylonsApp
    :members:
    
    .. automethod:: PylonsApp.__call__
