:mod:`pylons.controllers` -- Controllers
========================================

.. module:: pylons.controllers

This module makes available the
:class:`~pylons.controllers.core.WSGIController` and
:class:`~pylons.controllers.xmlrpc.XMLRPCController` for easier importing.
