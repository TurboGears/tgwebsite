:mod:`pylons.log` -- Logging for WSGI errors
============================================

.. automodule:: pylons.log

Module Contents
---------------

.. autoclass:: WSGIErrorsHandler
    :members:
