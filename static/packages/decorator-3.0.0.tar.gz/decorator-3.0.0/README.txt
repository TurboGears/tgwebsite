Decorator module
---------------------------

Dependencies:

The decorator module requires Python 2.4.

Installation:

Copy the file decorator.py somewhere in your Python path.

Testing:

Run

$ python documentation.py

This should work perfectly with Python 2.4 and Python 2.5 and give
minor errors with Python 2.6 (some inner details such as the
introduction of the ArgSpec namedtuple and Thread.__repr__ changed).
