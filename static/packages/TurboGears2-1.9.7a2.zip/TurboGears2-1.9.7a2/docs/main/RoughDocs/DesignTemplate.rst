## Please see the page "DocHelp" for guidelines on contributing TurboGears documentation!



Creating templates
==================

:Status: Work in progress

.. contents:: Table of Contents
    :depth: 2


TurboGears uses Genshi, a template language that is smart about markup, as the default template engine.

to be filled...


genshi syntax
--------------

to be filled...

Genshi gothcas
--------------

DO NOT USE 'data' as a key in the return dictionary of your controller. You will get an AttributeError for Context and an Internal Server Error rendered to the browser. There is no mention of 'data' being a reserved word.

Use other template engine
---------------------------

to be filled...


Reference:

http://genshi.edgewall.org/


