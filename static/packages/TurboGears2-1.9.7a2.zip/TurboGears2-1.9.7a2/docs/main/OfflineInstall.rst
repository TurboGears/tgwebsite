:status: Unofficial

An offline install of TG2 is not yet supported. 

But basically you need to follow these instructions

* http://docs.turbogears.org/1.0/OfflineInstall

But also get a SVN checkout of the TG2 sources, and a mercurial checkout of Pylons, along with eggs for their dependencies.



