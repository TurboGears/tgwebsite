:mod:`pylons.decorators` -- Decorators
======================================

.. automodule:: pylons.decorators

Module Contents
---------------

.. autofunction:: jsonify
.. autofunction:: validate
