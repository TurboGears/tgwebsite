:mod:`pylons.configuration` -- Configuration object and defaults setup
======================================================================

.. automodule:: pylons.configuration

Module Contents
---------------

.. autoclass:: PylonsConfig
    :members: init_app
