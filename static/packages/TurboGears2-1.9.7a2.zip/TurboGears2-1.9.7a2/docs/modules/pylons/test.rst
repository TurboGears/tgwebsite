:mod:`pylons.test` -- Test related functionality
================================================

.. automodule:: pylons.test

Module Contents
---------------

.. autoclass:: PylonsPlugin
