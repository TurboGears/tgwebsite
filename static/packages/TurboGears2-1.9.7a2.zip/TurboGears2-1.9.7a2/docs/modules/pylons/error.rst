:mod:`pylons.error` -- Error handling support
=============================================

.. automodule:: pylons.error
