:mod:`pylons.controllers.xmlrpc` -- XMLRPCController Class
==========================================================

.. automodule:: pylons.controllers.xmlrpc

Module Contents
---------------

.. autoclass:: XMLRPCController
    :members: __call__, system_listMethods, system_methodSignature, system_methodHelp
