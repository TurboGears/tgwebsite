:mod:`pylons.decorators.rest` -- REST-ful Decorators
====================================================

.. automodule:: pylons.decorators.rest

Module Contents
---------------

.. autofunction:: dispatch_on
.. autofunction:: restrict
