:mod:`webhelpers` -- helper functions for web applications
======================================================================

.. automodule:: webhelpers.paginate

Package Contents
----------------

.. autoclass:: Page

.. automethod:: Page.pager
