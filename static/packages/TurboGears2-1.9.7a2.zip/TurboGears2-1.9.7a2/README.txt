TurboGears2
===========

Next generation Front-to-back web development megaframework built on Pylons.

TurboGears2, provides a comprehensive web development toolkit.
It is designed to help you create the basic outline of a database-driven
web application in minutes.

TurboGears provides you with sane default for designer friendly templates,
tools to make  AJAX, and dynamic Javascript driven pages easy on both the
browser side and the server side.

TurboGears is a project that is built upon a foundation of reuse and building up.
In retrospect, much of the code that was home grown in the TurboGears project
should have been released as independent projects that integrate with TurboGears.

TurboGears is licensed under an MIT-style license (see LICENSE.txt).
Other incorporated projects may be licensed under different licenses.
All licenses allow for non-commercial and commercial use.

Working on TG2
--------------

To be able to build TG2 packages or install it for development, you
need Paver::

  easy_install Paver

You can then run::

  paver develop

to start working with the development version of TG2.
