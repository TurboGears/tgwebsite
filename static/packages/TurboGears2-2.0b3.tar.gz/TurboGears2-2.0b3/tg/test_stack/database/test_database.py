import os
from tg.test_stack import TestConfig, app_from_config   
from webtest import TestApp

def setup_DB():
    deployment_config = {'debug': 'true', 
                     'error_email_from': 'paste@localhost', 
                     'smtp_server': 'localhost',
                     'sqlalchemy.url': 'sqlite:///:memory:'}
    
    base_config = TestConfig(folder = 'database', 
                             values = {'use_sqlalchemy': True}
                             )
    return app_from_config(base_config, deployment_config)

app = setup_DB()

def test_setup():
    resp = app.get("/")
    assert foo in resp
