:mod:`routes` -- Routes Common Classes and Functions
====================================================

.. automodule:: routes

Module Contents
---------------

.. autofunction:: request_config
.. autoclass:: _RequestConfig
    :members:
    :undoc-members:
