Routes Documentation
====================

.. toctree::
   :maxdepth: 2
   
   introduction
   setting_up
   generating
   restful
   uni_redirect_rest

.. toctree::
   :maxdepth: 1

   glossary
   porting
   

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
* :ref:`glossary`

Module Listing
--------------

.. toctree::
    :maxdepth: 2

    modules/index
