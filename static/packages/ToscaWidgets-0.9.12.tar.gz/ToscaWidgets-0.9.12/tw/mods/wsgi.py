from tw.mods.base import HostFramework

__all__ = ["WSGIHostFramework"]

#TODO: Deprecate WSGIHostFramework
WSGIHostFramework = HostFramework

