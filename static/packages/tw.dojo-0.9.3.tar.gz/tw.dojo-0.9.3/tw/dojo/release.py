# Metadata for the widget EGG. Should leave it for the (unimplemented) widget
# tracker to track it

__PROJECT__ = 'tw.dojo'
__DESCRIPTION__ = 'Dojo 1.1 widget for ToscaWidgets'
__URL__ = 'http://toscawidgets.org/'
__VERSION__ = '0.9.3'
__AUTHOR__ = 'Michele Bertoldi and Christopher Perkins'
__EMAIL__ = "michele@vico10.com"
__COPYRIGHT__ = "Copyright 2008 Michele Bertoldi"
__LICENSE__ = 'MIT'
