Miscellaneous Tasks
===================

These are some other tasks that are located in the paver.misctasks module.

.. automodule:: paver.misctasks
    :members:
    