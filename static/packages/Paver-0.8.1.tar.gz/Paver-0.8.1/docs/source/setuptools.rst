.. _setuptools:

distutils and setuptools
========================

.. automodule:: paver.setuputils
   :members:
