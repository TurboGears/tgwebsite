.. _articles:
    
Articles about Paver
====================

* `Initial announcement`_ and background about the project
* `Release 0.7 announcement`_

.. _Initial announcement: http://www.blueskyonmars.com/2008/04/22/paver-and-the-building-distribution-deployment-etc-of-python-projects/

.. _Release 0.7 announcement: http://www.blueskyonmars.com/2008/05/07/paver-07-better-than-distutils-better-docs-and-much-more/
