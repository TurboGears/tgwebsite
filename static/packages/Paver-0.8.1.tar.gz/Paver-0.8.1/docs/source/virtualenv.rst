.. _virtualenv:

Virtualenv Support
==================

.. automodule:: paver.virtual
    :members:

