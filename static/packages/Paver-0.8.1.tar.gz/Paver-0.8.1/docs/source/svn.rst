.. _svn:

Using with Subversion
=====================

.. automodule:: paver.svn
   :members: