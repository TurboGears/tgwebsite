.. The New Way documentation master file, created by sphinx-quickstart on Sun May  4 14:02:06 2008.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

[[[section mainpart]]]
Welcome to The New Way's documentation!
=======================================

This is the Paver way of doing things. The key functionality here
is in this powerful piece of code, which I will `include` here in its entirety
so that you can bask in its power::

  # [[[cog include("newway/thecode.py", "code")]]]
  # [[[end]]]

[[[endsection]]]

Contents:

.. toctree::
   :maxdepth: 2

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

