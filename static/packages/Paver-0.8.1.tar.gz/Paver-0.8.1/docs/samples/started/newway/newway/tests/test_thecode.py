from newway.thecode import *

def test_the_function():
    output = powerful_function_and_new_too()
    assert output == 2, "Doh! Got %s instead" % (output)
    