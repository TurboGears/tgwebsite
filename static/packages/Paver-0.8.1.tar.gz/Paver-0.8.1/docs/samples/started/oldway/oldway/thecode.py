def powerful_function_but_still_old():
    """This is powerful stuff, but it's still the old way of
    doing things."""
    return 1+1
    