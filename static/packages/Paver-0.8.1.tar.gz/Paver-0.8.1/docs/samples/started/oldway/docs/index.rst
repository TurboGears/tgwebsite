.. The Old Way documentation master file, created by sphinx-quickstart on Sun May  4 14:02:06 2008.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to The Old Way's documentation!
=======================================

This is the old, pre-Paver way of doing things. The key functionality here
is in this powerful piece of code, which I will copy here in its entirety
so that you can bask in its power::

  def powerful_function_but_still_old():
      """This is powerful stuff, but it's still the old way of
      doing things."""
      return 1+1


Contents:

.. toctree::
   :maxdepth: 2

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

