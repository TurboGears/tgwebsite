from distutils.core import setup

# [[[section setup]]]
setup(
    name="TheOldWay",
    packages=['oldway'],
    version="1.0",
    author="Kevin Dangoor"
)
# [[[endsection]]]