:mod:`tg.decorators` -- Decorators
========================================

.. automodule:: tg.decorators
  :members: