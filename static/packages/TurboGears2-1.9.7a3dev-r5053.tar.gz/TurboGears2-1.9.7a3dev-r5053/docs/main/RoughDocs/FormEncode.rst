


FormEncode
==========

:Status: Work in progress

FormEncode is a validation and form generation package. The validation can be used separately from the form generation. The validation works on compound data structures, with all parts being nestable. It is separate from HTTP or any other input mechanism. FormEncode validators are used with ToscaWidgets.

http://docs.turbogears.org/1.0/RoughDocs/Validators
