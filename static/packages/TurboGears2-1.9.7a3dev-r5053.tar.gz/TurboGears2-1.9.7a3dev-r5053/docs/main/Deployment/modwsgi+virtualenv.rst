## Please see the page "DocHelp" for guidelines on contributing TurboGears documentation!


mod_wsgi
==========

:Status: stub 

mod_wsgi site documents how to use virtualenv:

http://code.google.com/p/modwsgi/wiki/VirtualEnvironments

You can then deploy your TG2 app as described here:

http://code.google.com/p/modwsgi/wiki/IntegrationWithPylons
