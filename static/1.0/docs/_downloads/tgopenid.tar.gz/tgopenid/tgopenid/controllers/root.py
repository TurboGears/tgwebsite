from turbogears import controllers, expose
from tgopenid.model import User
from turbogears import identity, redirect
from cherrypy import request, response
# from tgopenid import json
# import logging
# log = logging.getLogger("tgopenid.controllers")


########################################################
# Added for openid support
########################################################

import turbogears
from turbogears import flash
from pysqlite2 import dbapi2 as sqlite
from openid.consumer import consumer
from openid.store import sqlstore
from openid.cryptutil import randomString
from yadis.discover import DiscoveryFailure
from urljr.fetchers import HTTPFetchingError

# Utility functions

def _flatten(dictionary, inner_dict):
    """
    Given a dictionary like this:
        {'a':1, 'b':2, 'openid': {'i':1, 'j':2}, 'c': 4},
    flattens it to have:
        {'a':1, 'b':2, 'openid.i':1, 'openid.j':2, 'c':4}
    """
    if dictionary.has_key(inner_dict):
        d = dictionary.pop(inner_dict)
        for k in d.iterkeys():
            dictionary[inner_dict +'.' + k] = d[k]

def _prefix_keys(dictionary, prefix):
    " Prefixes the keys of dictionary with prefix "
    d = {}
    for k, v in dictionary.iteritems():
        d[prefix + '.' + k] = v
    return d

def _get_openid_store_connection():
    """
    Returns a connection to the database used
    by openid library
    Is it needed to close the connection? If yes, where to close it?
    """
    return sqlite.connect("openid.db")

def _get_openid_consumer():
    """
    Returns an openid consumer object
    """
    from cherrypy import session
    
    con = _get_openid_store_connection()
    store = sqlstore.SQLiteStore(con)
    session['openid_tray'] = session.get('openid_tray', {})
    return consumer.Consumer(session['openid_tray'], store)

def _get_previous_url(**kw):
    """
    if kw is something like
        {'previous_url' : 'some_controller_url',
         'openid_url'   : 'an_openid.myopenid.com',
         'password'     : 'some_password',
         'login'        : 'Login',
         'param1'       : 'param1'
         'param2'       : 'param2'
        }
    the value returned is
    http://xyz:8080/come_controller_url?user_name=an_openid.myopenid.com&password=some_password&login=Login&param1=param1&param2=param2
    """
    kw['user_name'] = kw['openid_url']
    del kw['openid_url']     
    previous_url = kw['previous_url']
    del kw['previous_url']
    return turbogears.url(previous_url, kw)

class Root(controllers.RootController):
    @expose(template="tgopenid.templates.welcome")
    # @identity.require(identity.in_group("admin"))
    def index(self):
        import time
        # log.debug("Happy TurboGears Controller Responding For Duty")
        return dict(now=time.ctime())

    @expose(template="tgopenid.templates.login")
    def login(self, forward_url=None, previous_url=None, *args, **kw):

        if not identity.current.anonymous \
            and identity.was_login_attempted() \
            and not identity.get_identity_errors():
            raise redirect(forward_url)

        forward_url=None
        previous_url= request.path

        if identity.was_login_attempted():
            msg=_("The credentials you supplied were not correct or "
                   "did not grant access to this resource.")
        elif identity.get_identity_errors():
            msg=_("You must provide your credentials before accessing "
                   "this resource.")
        else:
            msg=_("Please log in.")
            forward_url= request.headers.get("Referer", "/")
            
        response.status=403
        return dict(message=msg, previous_url=previous_url, logging_in=True,
                    original_parameters=request.params,
                    forward_url=forward_url)

    @expose()
    def logout(self):
        identity.current.logout()
        raise redirect("/")

    @expose()
    def login_begin(self, **kw):
        if len(kw['openid_url']) == 0:  #openid_url was not provided by the user
            flash('Please enter your openid url')
            raise redirect(_get_previous_url(**kw))
            
        oidconsumer = _get_openid_consumer()
        try:
            req = oidconsumer.begin(kw['openid_url'])
        except HTTPFetchingError, exc:
            flash('HTTPFetchingError retrieving identity URL (%s): %s' % (kw['openid_url'], str(exc.why)))
            raise redirect(_get_previous_url(**kw))
        except DiscoveryFailure, exc:
            flash('DiscoveryFailure Error retrieving identity URL (%s): %s' % (kw['openid_url'], str(exc[0])))
            raise redirect(_get_previous_url(**kw))
        else:
            if req is None:
                flash('No OpenID services found for %s' % (kw['openid_url'],))
                raise redirect(_get_previous_url(**kw))
            else:
                
                # Add server.webpath variable
                # in your configuration file for turbogears.url to
                # produce full complete urls
                # e.g. server.webpath="http://localhost:8080"
                
                trust_root = turbogears.url('/')
                return_to = turbogears.url('/login_finish', _prefix_keys(kw, 'app_data'))
                
                # As we want also to fetch nickname and email
                # of the user from the server,
                # we have added the line below
                req.addExtensionArg('sreg', 'optional', 'nickname,email')
                req.addExtensionArg('sreg', 'policy_url', 'http://www.google.com')
                
                redirect_url = req.redirectURL(trust_root, return_to)
                raise redirect(redirect_url)

    @expose()
    def login_finish(self, **kw):
        """Handle the redirect from the OpenID server.
        """
        app_data = kw.pop('app_data')
        # As consumer.complete needs a single flattened dictionery,
        # we have to flatten kw. See flatten's doc string
        # for what it exactly does
        _flatten(kw, 'openid')
        _flatten(kw, 'openid.sreg')
        
        oidconsumer = _get_openid_consumer()
        info = oidconsumer.complete(kw)
        if info.status == consumer.FAILURE and info.identity_url:
            # In the case of failure, if info is non-None, it is the
            # URL that we were verifying. We include it in the error
            # message to help the user figure out what happened.
            flash("Verification of %s failed. %s") & (info.identity_url, info.message)
            raise redirect(_get_previous_url(**app_data))
        elif info.status == consumer.SUCCESS:
            # Success means that the transaction completed without
            # error. If info is None, it means that the user cancelled
            # the verification.

            # This is a successful verification attempt.

            # identity url may be like http://yourid.myopenid.com/
            # strip it to yourid.myopenid.com
            user_name = info.identity_url.rstrip('/').rsplit('/', 1)[-1]

            # get sreg information about the user
            user_info = info.extensionResponse('sreg')

            u = User.get_by(user_name=user_name)
            if u is None: # new user, not found in database
                u = User(user_name=user_name)
            if user_info.has_key('email'):
                u.email_address = user_info['email']
            if user_info.has_key('nickname'):
                u.display_name = user_info['nickname']
            u.password = randomString(8, "abcdefghijklmnopqrstuvwxyz0123456789")
            try:
                u.flush()
            except Exception, e:
                flash('Error saving user: ' + str(e))
                raise redirect(turbogears.url('/'))
            app_data['openid_url'] = user_name
            app_data['password'] = u.password
            raise redirect(_get_previous_url(**app_data))
        elif info.status == consumer.CANCEL:
            # cancelled
            flash('Verification cancelled')
            raise redirect(turbogears.url('/'))
            
        else:
            # Either we don't understand the code or there is no
            # openid_url included with the error. Give a generic
            # failure message. The library should supply debug
            # information in a log.
            flash('Verification failed')
            raise redirect(turbogears.url('/'))
            
    @expose()
    @identity.require(identity.not_anonymous())
    def whoami(self, **kw):
        u = identity.current.user
        return "\nYour openid_url: " + u.user_name + \
               "\nYour email_address: " + u.email_address + \
               "\nYour nickname: " + u.display_name + \
               "\nThe following parameters were supplied by you: " + str(kw)
