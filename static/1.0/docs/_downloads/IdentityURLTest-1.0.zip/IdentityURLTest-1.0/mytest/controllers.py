import turbogears as tg
from turbogears import controllers, expose, flash
from turbogears import identity, redirect
from cherrypy import request, response
from sqlobject import SQLObjectNotFound

from mytest import model

# Set the identity failure URL to our custom function
def failure_url(errors):
    """If the user is alreday logged in, redirect to a different URL."""
    if not identity.current.anonymous:
        return tg.url('/access_denied')
    return tg.url('/login')

tg.config.update({'identity.failure_url': failure_url})


# our custom identity predicate
class is_admin(identity.Predicate, identity.IdentityPredicateHelper):
    """Check whether current identity is a member of the 'admin' group."""
    error_message = _(u"You are not a member of the '%(group)s' group.")

    def __init__(self):
        self.group = 'admin'

    def eval_with_object(self, identity, errors=None):
        if self.group not in identity.groups:
            # This will add self.error_message to the identity errors.
            # They can be retrieved later with identity.get_identity_errors()
            self.append_error_message(errors)
            return False
        return True

class Root(controllers.RootController):
    @expose(template="mytest.templates.welcome")
    def index(self):
        """Show the welcome page."""
        return dict()

    @expose()
    def create_user(self):
        """Create a test user (if it not already exists)."""
        try:
            u = model.User.by_user_name(u'test')
            tg.flash(_(u"Test user was already created. "
                "Username/password: test/test"))
        except SQLObjectNotFound:
            u = model.User(user_name=u'test', display_name=u'Test User',
                email_address=u'test@foo.com', password=u'test')
            u.sync()
            tg.flash(_(u"Test user successfully created. "
                "Username/password: test/test"))
        tg.redirect('/')

    @expose()
    def toggle_admin(self):
        """Toggle membership of the test user in the 'admin' group'."""
        try:
            u = model.User.by_user_name(u'test')
        except SQLObjectNotFound:
            tg.flash(_(u'You must create a test user first.'))
        else:
            try:
                g = model.Group.by_group_name(u'admin')
            except SQLObjectNotFound:
                g = model.Group(group_name=u'admin',
                    display_name=u'Administrators')
            if g in u.groups:
                u.removeGroup(g)
                tg.flash(_(u"Removed test user from 'admin' group."))
            else:
                u.addGroup(g)
                tg.flash(_(u"Added test user to 'admin' group."))
            u.sync()
        redirect('/')

    @expose(template='mytest.templates.generic')
    @identity.require(identity.not_anonymous())
    def restricted1(self, *args, **kwargs):
        """Show the restricted area 1 page.

        Acess to this method is restricted by the standard identity predicate
        'identity.not_anonymous', which checks if the current visitor is
        logged in.

        """
        tg.flash(_(u"Access granted (restricted area 1)."))
        return dict()

    @expose(template='mytest.templates.generic')
    @identity.require(is_admin())
    def restricted2(self, *args, **kwargs):
        """Show the restricted area 2 page.

        Acess to this method is restricetd by our custom identity predicate
        'is_admin', which checks if the current identity is a member of the
        'admin' group.

        """
        tg.flash(_(u"Access granted (restricted area 2)."))
        return dict()

    @expose(template='mytest.templates.generic')
    def access_denied(self, *args, **kwargs):
        """Show the 'access denied' message to already logegd in users."""
        msgs = [_(u"Access denied.")]
        # get the error messages from the identity failures
        # they will be shown by the template if present
        msgs.extend(identity.get_identity_errors())
        return dict(
            messages = msgs,
            args = args,
            kwargs = kwargs
        )

    @expose(template="mytest.templates.login")
    def login(self, forward_url=None, *args, **kw):
        """Show the login form."""
        if forward_url:
            if isinstance(forward_url, list):
                forward_url = forward_url.pop(0)
            else:
                del request.params['forward_url']

        if not identity.current.anonymous and identity.was_login_attempted() \
                and not identity.get_identity_errors():
            redirect(tg.url(forward_url or '/', kw))

        if identity.was_login_attempted():
            msg = _("The credentials you supplied were not correct or "
                   "did not grant access to this resource.")
        elif identity.get_identity_errors():
            msg = _("You must provide your credentials before accessing "
                   "this resource.")
            if not forward_url:
                forward_url = request.path_info
        else:
            msg = _("Please log in.")
            if not forward_url:
                forward_url = request.headers.get("Referer", "/")

        response.status = 401
        return dict(logging_in=True, message=msg,
            forward_url=forward_url, previous_url=request.path_info,
            original_parameters=request.params)

    @expose()
    def logout(self):
        """Log out the current user and return to start page."""
        identity.current.logout()
        redirect("/")
