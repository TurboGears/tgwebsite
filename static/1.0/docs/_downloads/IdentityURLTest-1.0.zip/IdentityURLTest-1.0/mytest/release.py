# Release information about IdentityURLTest

version = "1.0"

description = """\
A small TurboGears example application demomonstrating how to use several
advanced identity framework features."""

author = "Christopher Arndt"
email = "turbogears@googlegroups.com"
copyright = "(c) 2008 TurboGears"

url = "http://docs.turbogears.org/1.0/IdentityFailureUrl"
download_url = url
license = "MIT"
