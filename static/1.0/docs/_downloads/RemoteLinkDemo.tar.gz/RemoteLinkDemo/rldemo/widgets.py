# widgets.py

from turbogears.widgets import Widget, mochikit

class RemoteLink(Widget):
    """When the target link is clicked, use XMLHttpRequest to get a
    response from a remote method and use the result to update the div.

    """
    name = "RemoteLink"

    javascript = [mochikit]

    template = """\
        <script type="text/javascript">
        addLoadEvent(
            function() {
                connect('${target}', 'onclick',
                    function (e) {
                        e.preventDefault();
                        var d = doSimpleXMLHttpRequest('${href}');
                        d.addCallback(${action});
                    }
                );
            }
        );

        function ${action}(result) {
            replaceChildNodes('${update}', result.responseText);
        }
        </script>
    """
    params = ["target", "update", "href", "action"]
    params_doc = dict(
        action = "JS function handling the response, default is 'showDiv'",
        href = "URL of the remote method to call",
        target = "The link ID",
        update = "DIV to be replaced"
    )
    action="showDiv"

