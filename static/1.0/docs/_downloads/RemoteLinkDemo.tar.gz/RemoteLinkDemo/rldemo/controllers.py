# controllers.py

import time
from turbogears import controllers, expose
from widgets import RemoteLink

class Root(controllers.RootController):
    @expose(template=".templates.welcome")
    def index(self):
        remote_link = RemoteLink()
        return dict(now=time.ctime(), remote_link=remote_link)

    @expose()
    def time(self):
        import time
        return time.ctime()
