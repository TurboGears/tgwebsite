# Release information about RemoteLinkDemo

version = "1.0"

description = "Example code for the 1.0/RemoteLink page on the TG docs wiki"
# long_description = "More description about your plan"
author = "Fred Lin, Christopher Arndt"
email = "chris@chrisarndt.de"
copyright = "Vintage 2007-2008 - a good year indeed"

# if it's open source, you might want to specify these
url = "http://docs.turbogears.org/1.0/RemoteLink"
download_url = "http://docs.turbogears.org/1.0/RemoteLink"
license = "MIT"
