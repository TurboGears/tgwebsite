import logging

import cherrypy

import turbogears
from turbogears import controllers, expose, validate, redirect

from wgtest import json

from plotkit import EasyPlot

class Root(controllers.RootController):
    @expose(template="wgtest.templates.welcome")
    def index(self):
        setA = [[0,0], [1,2], [2,3], [3,7], [4,8], [5,6]]
        setB = [[0,0], [1,1], [2,4], [3,8], [4,7], [5,20]]
        setC = [[0,1], [1,3], [2,5], [3,5], [4,3], [5,2]]
        return dict(ep= EasyPlot(id="diag",
                 style="line",
                 width="300",
                 height="300",
                 data=[setA, setB, setC]))
