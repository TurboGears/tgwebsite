from sqlobject import *

from turbogears.database import PackageHub

hub = PackageHub("wgtest")
__connection__ = hub

# class YourDataClass(SQLObject):
#     pass

