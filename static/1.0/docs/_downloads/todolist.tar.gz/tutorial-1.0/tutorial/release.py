# Release information

version = "1.0"

description = "To-Do-List Tuturial"
long_description = "To-Do-List Tutorial for TurboGears 1.0 created by Brian Beck"
author = "Brian Beck"
email = "brian.beck@gmail.com"
copyright = "Copyright (c) 2006 Brian Beck"
url = "http://www.turbogears.org/1.0/docs/ToDoListTutorial.html"
download_url = "http://www.turbogears.org/1.0/docs/_downloads/todolist.tar.gz"
license = "MIT"

