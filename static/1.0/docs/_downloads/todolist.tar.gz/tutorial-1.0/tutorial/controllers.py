
from turbogears import controllers, expose, flash, redirect
from turbogears.toolbox.catwalk import CatWalk

from tutorial import model


class Users:

    @expose("tutorial.templates.users")
    def index(self):
        users = model.User.select()
        return dict(users=users)

    @expose("tutorial.templates.user")
    def default(self, userID):
        try:
            userID = int(userID)
            user = model.User.get(userID)
        except (ValueError, model.SQLObjectNotFound):
            raise cherrypy.NotFound
        else:
            return dict(user=user)

    @expose()
    def add(self, email):
        # Remove extra spaces
        email = email.strip()
        # Remove null bytes (they can seriously screw up the database)
        email = email.replace('\x00', '')
        if email:
            try:
                user = model.User.byEmail(email)
            except model.SQLObjectNotFound:
                user = model.User(email=email)
                flash("User %s added!" % email)
            else:
                flash("User %s already exists!" % email)
        else:
            flash("E-mail must be non-empty!")
        redirect('/users/')

    @expose()
    def remove(self, email):
        try:
            user = model.User.byEmail(email)
        except model.SQLObjectNotFound:
            flash("The user %s does not exist."
                " (Did someone else remove it?)" % email)
        else:
            for userlist in user.lists:
                for item in userlist.items:
                    item.destroySelf()
                userlist.destroySelf()
            user.destroySelf()
            flash("User %s removed!" % email)
        redirect('/users/')


class Root(controllers.RootController):

    users = Users()

    catwalk = CatWalk(model)

    @expose("tutorial.templates.welcome")
    def index(self):
        return dict()

    @expose("tutorial.templates.about")
    def about(self, author="Brian Beck"):
        return dict(author=author)

    @expose()
    def addList(self, userID, title):
        try:
            userID = int(userID)
            user = model.User.get(userID)
        except (ValueError, model.SQLObjectNotFound):
            flash("Cannot add list - user not found!")
        else:
            # Remove extra spaces
            title = title.strip()
            # Remove null bytes (they can seriously screw up the database)
            title = title.replace('\x00', '')
            if title:
                model.List(title=title, user=user)
                flash("List created!")
            else:
                flash("Title must be non-empty!")
        redirect('/users/%s' % userID)

    @expose()
    def removeList(self, userID, listID):
        try:
            listID = int(listID)
            userlist = model.List.get(listID)
        except ValueError:
            flash("Invalid list!")
        except model.SQLObjectNotFound:
            flash("List not found! (Did someone else remove it?)")
        else:
            for item in userlist.items:
                item.destroySelf()
            userlist.destroySelf()
            flash("List deleted!")
        redirect('/users/%s' % userID)

    @expose()
    def addItem(self, userID, listID, value):
        try:
            listID = int(listID)
            userlist = model.List.get(listID)
        except ValueError:
            flash("Invalid list!")
        except model.SQLObjectNotFound:
            flash("List not found! (Did someone else remove it?)")
        else:
            # Remove extra spaces
            value = value.strip()
            # Remove null bytes (they can seriously screw up the database)
            value = value.replace('\x00', '')
            if value:
                item = model.Item(listID=listID, value=value)
                flash("Item added!")
            else:
                flash("Item must be non-empty!")
        redirect('/users/%s' % userID)

    @expose()
    def removeItem(self, userID, itemID):
        try:
            itemID = int(itemID)
            item = model.Item.get(itemID)
        except ValueError:
            flash("Invalid item!")
        except model.SQLObjectNotFound:
            flash("No such item! (Did someone else remove it?)")
        else:
            item.destroySelf()
            flash("Item removed!")
        redirect('/users/%s' % userID)

    @expose(format='json')
    def editItem(self, itemID, value):
        try:
            itemID = int(itemID)
            item = model.Item.get(itemID)
        except (ValueError, model.SQLObjectNotFound):
            pass
        else:
            # Remove extra spaces
            value = value.strip()
            # Remove null bytes (they can seriously screw up the database)
            value = value.replace('\x00', '')
            if value:
                item.value = value
            else:
                value = item.value
        return dict(value=value)
