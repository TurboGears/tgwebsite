import pkg_resources
pkg_resources.require("SQLObject>=0.10.1,<0.12dev")

from turbogears.database import PackageHub

from sqlobject import SQLObject, SQLObjectNotFound, \
    ForeignKey, MultipleJoin, StringCol, UnicodeCol

__connection__ = hub = PackageHub('tutorial')

# data model for the to-do-list

class User(SQLObject):
    email = StringCol(alternateID=True)
    lists = MultipleJoin('List')

class List(SQLObject):
    title = UnicodeCol(notNone=True)
    user = ForeignKey('User')
    items = MultipleJoin('Item')

class Item(SQLObject):
    value = UnicodeCol(notNone=True)
    list = ForeignKey('List')
