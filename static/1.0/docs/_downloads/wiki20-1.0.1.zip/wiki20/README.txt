Wiki-20

This is the tutorial project for TurboGears 1.0. You can view the tutorial by
visiting:

http://docs.turbogears.org/1.0/Wiki20/

This project is configured to use a sqlite database that will be created in the same directiory as this README file.

If you have problems, post on the TurboGears discussion list:

http://groups.google.com/group/turbogears

Happy Hacking.
