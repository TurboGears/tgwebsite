#import logging
#
#import cherrypy
#
#import turbogears
#from turbogears import controllers, expose, validate, redirect
#
#from remoteform import json
#
#log = logging.getLogger("remoteform.controllers")

from turbogears.widgets.base import WidgetsList
from turbogears.widgets import TextField, CheckBox, RadioButtonList, RemoteForm
from turbogears import controllers
import turbogears

class SearchFormFields(WidgetsList):
    name = TextField()
    age = TextField()
    check = CheckBox()
    radio = RadioButtonList(options=[(1, "Python"),
                                     (2, "Java"),
                                     (3, "Pascal"),
                                     (4, "Ruby")],
                                     default=4)

class Root(controllers.RootController):
    """ Demonstrate the use of RemoteForm. """
    @turbogears.expose(template="rf_demo.templates.welcome")
    def index(self):
        item_searchform = RemoteForm(
           name="ItemSearch",
           fields=SearchFormFields(),
           submit_text="Search")
        return dict(item_searchform=item_searchform)

    @turbogears.expose()
    def do_search(self, **kw):
        """ Echo the parameters back as html."""
        return "<div>Recieved data:<br>%r</br></div>" % kw
