from sqlobject import *

from turbogears.database import PackageHub

hub = PackageHub("rf_demo")
__connection__ = hub

# class YourDataClass(SQLObject):
#     pass

