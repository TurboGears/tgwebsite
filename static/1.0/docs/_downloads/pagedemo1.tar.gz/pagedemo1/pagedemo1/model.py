from sqlobject import *

from turbogears.database import PackageHub

hub = PackageHub("pagedemo1")
__connection__ = hub


class Person(SQLObject):
    """Clase Articulo"""

    name = StringCol(length=50)
    age = IntCol()
