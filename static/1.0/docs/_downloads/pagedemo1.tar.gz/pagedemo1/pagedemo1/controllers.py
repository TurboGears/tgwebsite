
import logging

from turbogears import controllers, expose, paginate
from turbogears.widgets import PaginateDataGrid

from model import Person

log = logging.getLogger("pagedemo2.controllers")


# The datagrids used for this demo:

person_list = PaginateDataGrid(
    fields=[
        PaginateDataGrid.Column('name', 'name', 'Name'),
        PaginateDataGrid.Column('age', 'age', 'Age'),
    ])

sortable_person_list = PaginateDataGrid(
    fields=[
        PaginateDataGrid.Column('name', 'name', 'Name',
            options=dict(sortable=True)),
        PaginateDataGrid.Column('age', 'age', 'Age',
            options=dict(sortable=True, reverse_order=True)),
    ])

try:
    from xml.etree import ElementTree
except ImportError:
    from elementtree import ElementTree

class MakeLink:
    """Generate the link inside the datagrid."""

    def __init__(self, baseurl, id, title, action):
        self.baseurl = baseurl
        self.id = id
        self.title = title
        self.action = action

    def __call__(self, obj):
        url = controllers.url(self.baseurl,
            dict(id=obj[self.id], action=self.action))
        link = ElementTree.Element(
            'a', href=url, style='text-decoration: underline')
        link.text = obj[self.title]
        return link

# to get this kind of link :  http://localhost:8080/person?action=edit&id=6
mylink = MakeLink('person', 'id', 'name', 'edit')

# just to get a element from a dictionary
def get(fieldname):
    return lambda x: x.get(fieldname)

data_grid = PaginateDataGrid(
    fields = [
        PaginateDataGrid.Column(name='name', getter=mylink, title='Name',
            options=dict(sortable=True)),
        PaginateDataGrid.Column(name='age', getter=get('age'), title='Age',
            options=dict(sortable=True, reverse_order=True)),
    ])


# The TurboGears paginate demo 1 controller:

class Root(controllers.RootController):

    @expose(template='.templates.welcome')
    def index(self):
        return dict(persons=None)

    # paginate1 will paginate using tg.paginate
    @expose(template='.templates.paginate1')
    @paginate('persons')
    def paginate1(self):
        persons = Person.select()
        return dict(persons=persons)

    # paginate2 will paginate automatically using PaginateDataGrid
    @expose(template='.templates.paginate2')
    @paginate('persons')
    def paginate2(self):
        persons = Person.select()
        return dict(persons=persons, list=person_list)

    # paginate3 is like paginate2 except it has sorting support
    @expose(template='.templates.paginate2')
    @paginate('persons', default_order='name')
    def paginate3(self):
        persons = Person.select()
        return dict(persons=persons, list=sortable_person_list)

    # paginate4 is like paginate3 except it does not use SQL
    @expose(template='.templates.paginate2')
    @paginate('persons', default_order='name')
    def paginate4(self):
        return dict(persons=self.persons(), list=data_grid)

    # paginate5 is like paginate4 except it does not use PaginateDataGrid
    @expose(template='.templates.paginate5')
    @paginate('persons')
    def paginate5(self):
        return dict(persons=self.persons())

    def persons(self):
        return [dict(id=i, name='name%d'%i, age=100-i) for i in range(100)]

    @expose(template='.templates.person')
    def person(self, id, action):
        person = self.persons()[int(id)]
        return dict(person=person)

    # TODO: add a controller that filters a .select() using data from a form.
    # paginate urlencodes all the input_values so it will work even on filtered
    # results

    # add some persons
    @expose()
    def populate(self):
        for i in range(1, 100):
            Person(name='dummy%i'%i, age=i)
        return 'done!'
