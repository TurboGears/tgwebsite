from sqlobject import *
from turbogears.database import PackageHub

hub = PackageHub("toddswiki")
__connection__ = hub

# class YourDataClass(SQLObject):
#     pass

class Page(SQLObject):
	pagename = StringCol(alternateID=True, length=30)
	data = StringCol()
	attached_files = RelatedJoin('UploadedFile')

class UploadedFile(SQLObject):
	filename = StringCol(alternateID=True)
	abspath = StringCol()
	size = IntCol()
	referenced_in_pages = RelatedJoin('Page')
