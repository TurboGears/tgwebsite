import turbogears, cherrypy, re
from turbogears import controllers, validators
from model import Page, hub, UploadedFile
from docutils.core import publish_parts
from sqlobject import SQLObjectNotFound
import os


wikiwords = re.compile(r"\b([A-Z]\w+[A-Z]+\w+)")

#default upload dir to ./uploads
UPLOAD_DIR = cherrypy.config.get("wiki.uploads", os.path.join(os.getcwd(),"uploads"))
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR) 

class Root(controllers.Root):
	@turbogears.expose(html="toddswiki.templates.welcome")
	def index(self):
		import time
		return dict(now=time.ctime())

	@turbogears.expose(html="toddswiki.templates.page")
	def index(self, pagename="FrontPage"):
		try:
			page = Page.byPagename(pagename)
			uploads = [item.filename for item in page.attached_files]
		except SQLObjectNotFound:
			raise cherrypy.HTTPRedirect(turbogears.url("/notfound",pagename=pagename))
		try:
			content = publish_parts(page.data, writer_name="html")["html_body"]
		except:
			content = page.data

		root = str(turbogears.url("/"))
		content = wikiwords.sub(r'<a href="%s\1">\1</a>' % root, content)
		content = content.encode("utf8")
		return dict(data=content, pagename=page.pagename, uploads=uploads)

	@turbogears.expose(html="toddswiki.templates.edit")
	def notfound(self, pagename):
		return dict(pagename=pagename, data="", new=True, uploads=[])

	@turbogears.expose(html="toddswiki.templates.edit")
	def edit(self, pagename):
		page = Page.byPagename(pagename)
		uploads = [item.filename for item in page.attached_files]
		return dict(pagename=page.pagename, data=page.data, new=False, uploads=uploads)

	@turbogears.expose(validators=dict(new=validators.StringBoolean()))
	def save(self, pagename, data, submit, new):
		hub.begin()
		if new:
			page = Page(pagename=pagename, data=data)
		else:
			page = Page.byPagename(pagename)
			page.data = data
		hub.commit()
		hub.end()
		turbogears.flash("Changes saved")
		new = False
		raise cherrypy.HTTPRedirect(turbogears.url("/%s" % pagename))

	@turbogears.expose(html="toddswiki.templates.page")
	def default(self, pagename):
		return self.index(pagename)
	
	@turbogears.expose(html="toddswiki.templates.pagelist")
	def pagelist(self):
		pages = [page.pagename for page in Page.select(orderBy=Page.q.pagename)]
		return dict(pages=pages)

	@turbogears.expose()
	def upload(self, upload_file, pagename, new, **keywords):
		try:
			p = Page.byPagename(pagename)
		except SQLObjectNotFound:
			turbogears.flash("Must save page first")
			raise cherrypy.HTTPRedirect(turbogears.url("/%s" % pagename))
		
		total_data=''
		while True:
			data = upload_file.file.read(8192)
			if not data:
				break
			total_data += data
		target_file_name = os.path.join(os.getcwd(),UPLOAD_DIR,upload_file.filename)
		try:
			u =  UploadedFile.byFilename(upload_file.filename)
			turbogears.flash("File already uploaded: %s is already at %s" %  (upload_file.filename, target_file_name))
		except SQLObjectNotFound:
			f = open(target_file_name, 'w')
			f.write(total_data)
			f.close
			turbogears.flash("File uploaded successfully: %s saved as : %s" % (upload_file.filename, target_file_name))
			u = UploadedFile(filename=upload_file.filename, abspath=target_file_name, size=0)
			
		Page.byPagename(pagename).addUploadedFile(u)
		raise cherrypy.HTTPRedirect(turbogears.url("/%s" % pagename))


	@turbogears.expose()
	def download(self, filename):
		uf = UploadedFile.byFilename(filename)
		return cherrypy.lib.cptools.serveFile(uf.abspath, "application/x-download", "attachment", uf.filename)
		
