from turbogears import controllers, expose, flash, redirect
from cherrypy import HTTPError, response, request

import pkg_resources
try:
    pkg_resources.require("SQLObject>=0.8")
except pkg_resources.DistributionNotFound:
    import sys
    print >> sys.stderr, """\
You are required to install SQLObject but appear not to have done so.
Please run your projects setup.py or run `easy_install SQLObject`.
"""
    sys.exit(1)
from turbogears import identity

from errortest.errorhandling import ErrorCatcher

import logging
log = logging.getLogger("errortest.controllers")

class Root(ErrorCatcher):
    @expose(template="errortest.templates.welcome")
    def index(self):
        import time
        log.debug("Happy TurboGears Controller Responding For Duty")
        flash(_(u'Your application is now running'))
        return dict(now=time.ctime())

    @expose()
    def error(self):
        raise RuntimeError(_(u'My hovercraft is full of eels!'))

    @expose()
    def noauth(self):
        raise HTTPError(401, _(u'Do I know you?'))

    @expose()
    def notallowed(self):
        raise HTTPError(403, _(u'Thou shall not PASS!'))

    @expose(template="errortest.templates.login")
    def login(self, forward_url=None, previous_url=None, *args, **kw):

        if not identity.current.anonymous \
            and identity.was_login_attempted() \
            and not identity.get_identity_errors():
            raise redirect(forward_url)

        forward_url=None
        previous_url= request.path

        if identity.was_login_attempted():
            msg=_(u'The credentials you supplied were not correct or '
                   u'did not grant access to this resource.')
        elif identity.get_identity_errors():
            msg=_(u'You must provide your credentials before accessing '
                   u'this resource.')
        else:
            msg=_(u'Please log in.')
            forward_url= request.headers.get("Referer", "/")

        response.status=403
        return dict(message=msg, previous_url=previous_url, logging_in=True,
                    original_parameters=request.params,
                    forward_url=forward_url)

    @expose()
    def logout(self):
        identity.current.logout()
        raise redirect("/")
