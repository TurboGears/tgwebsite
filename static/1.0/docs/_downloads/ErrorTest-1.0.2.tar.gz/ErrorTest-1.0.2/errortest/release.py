# Release information about ErrorTest

version = "1.0.2"

description = "TurboGears example application for the ErrorCatcher controller."
# long_description = "More description about your plan"
author = "Christopher Arndt"
email = "chris@chrisarndt.de"
copyright = "(c) 2008 - another good year so far"

# if it's open source, you might want to specify these
url = "http://docs.turbogears.org/1.0/ErrorReporting"
download_url = url
license = "MIT"
