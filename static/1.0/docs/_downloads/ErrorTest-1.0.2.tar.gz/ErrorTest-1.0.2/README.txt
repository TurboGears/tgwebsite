ErrorTest
=========

:Autor: Christopher Arndt
:Date: 2008-08-21
:Version: 1.0.2

This is a TurboGears example application for the ErrorCatcher controller.


Installation
------------

* Unpack the distribution archive.
* Change into the created directory ``ErrorTest-X.Y``.
* Run ``easy_install .``


Usage
-----

The application can be started by running the ``start-errortest`` script,
which will be installed along with the application. You must supply a
configuration file on the command line, e.g.::

    start-errortest dev.cfg

You can use the provided files ``dev.cfg`` and ``prod.cfg`` as examples, they
contain appropriate comments. Be sure to set at least the following options::

    error_catcher.on = True
    mail.on = True
    mail.server = '<your mail server'
    error_catcher.sender_email = '<sender email address>'
    error_catcher.admin_email = '<your email>'

See the docstrings in ``errorhandling.py`` for more information.


Acknowledgments
---------------

The code for ``errorhandler.py`` is based on an example in the TurboGears
documentation wiki on the page ErrorReporting_ by Felix Schwarz.


.. _errorreporting: http://docs.turbogears.org/1.0/ErrorReporting
