
"""Paginate Demo Controller"""

import logging
import sys
from operator import itemgetter
from random import normalvariate, sample
from cherrypy import request, response
from turbogears import (controllers, expose, flash, identity, paginate,
    redirect, url, validate, validators)
from turbogears.widgets import PaginateDataGrid
from pagedemo2.model import Group, User
from pagedemo2.lib.widgets import ImageLink
from pagedemo2.lib.names import generate_groups, generate_users

log = logging.getLogger("pagedemo2.controllers")


# Grids for the User Management demo:

sortable = dict(sortable=True)

group_grid = PaginateDataGrid(name='Group',
    fields=[
        ('ID', 'id', sortable),
        ('Groupname', 'group_name', sortable),
        ('Full Name', 'display_name', sortable),
        ('Members', 'num_members', sortable),
        ('Eldest', 'eldest.display_name', sortable),
        ('', lambda group: ImageLink(link=url('group',
                group_id=group.id, query=request.query_string))())
    ])

user_grid = PaginateDataGrid(name='User',
    fields=[
        ('ID', 'id', sortable),
        ('Username', 'user_name', sortable),
        ('First Name', 'first_name', sortable),
        ('Last Name', 'last_name', sortable),
        ('Age', 'age',  sortable),
        ('Email Address', 'email_address', sortable),
        ('Password', 'password', sortable),
        ('Groups', 'num_groups', sortable),
        ('', lambda user: ImageLink(link=url('user',
                user_id=user.id, query=request.query_string))())
    ])


# Data and grid for the Python Modules demo:

modules = sys.modules
modules = [modules[name] for name in sorted(modules)
    if not name.startswith('_') and not '._' in name
        and modules[name]
        and (getattr(modules[name], '__doc__', '') or '').strip()]

def summary(s, max=76):
    s = s.lstrip().split('\n', 1)
    s, t = s[0].rstrip(), len(s) > 1 and s[1][:1] != '\n'
    if len(s) > max:
        s, t = s[:max-4].rsplit(' ', 1)[0], True
    if t:
        s += ' ...'
    return s

modules_grid = PaginateDataGrid(name='Python Modules',
    fields=[
        ('Name', '__name__'),
        ('Content', lambda module: summary(module.__doc__))
    ])


# Grid for the Fibonacci Number demo:

fibonacci_grid = PaginateDataGrid(name='Fibonacci Numbers',
    fields=[
        ('n', itemgetter(0)),
        ('F(n)', itemgetter(1))
    ])


# The TurboGears paginate demo 2 controller:

class Root(controllers.RootController):

    @expose(template="pagedemo2.templates.index")
    def index(self):
        return dict()

    @expose(template="pagedemo2.templates.grid")
    @paginate('data', limit=14, default_order='group_name')
    def groups(self):
        groups = Group.select()
        count = groups.count()
        return dict(grid=group_grid, data=groups, count=count)

    @expose(template="pagedemo2.templates.view")
    @validate(validators=dict(group_id=validators.Int(not_empty=True),
        query = validators.UnicodeString()))
    def group(self, group_id, query=None):
        query = query and '?' + query or ''
        return dict(data=Group.get(group_id), backlink=url('groups' + query))

    @expose(template="pagedemo2.templates.grid")
    @paginate('data', default_order='user_name')
    def users(self):
        users = User.select()
        count = users.count()
        return dict(grid=user_grid, data=users, count=count)

    @expose(template="pagedemo2.templates.users")
    @paginate('users', max_pages=None, default_order='user_name')
    def users2(self):
        users = User.select()
        count = users.count()
        return dict(users=users, count=count)

    @expose(template="pagedemo2.templates.view")
    @validate(validators=dict(user_id=validators.Int(not_empty=True),
        query = validators.UnicodeString()))
    def user(self, user_id, query=None):
        query = query and '?' + query or ''
        return dict(data=User.get(user_id), backlink=url('users' + query))

    @expose()
    def populate(self):
        if User.select().count():
            flash("The tables are already populated.")
        else:
            for user in generate_users():
                User(**user)
            for group in generate_groups():
                Group(**group)
            groups = list(Group.select())
            for user in User.select():
                for group in sample(groups,
                        min(10, max(1, int(round(normalvariate(5, 3)))))):
                    user.addGroup(group)
            flash("The tables have been populated now.")
        redirect("/")

    @expose()
    def truncate(self):
        if User.select().count():
            for group in Group.select():
                for user in group.users:
                    group.removeUser(user)
            User.deleteMany(None)
            Group.deleteMany(None)
            flash("The tables have been truncated now.")
        else:
            flash("The tables are already truncated.")
        redirect("/")

    @expose(template="pagedemo2.templates.grid")
    @paginate('data', default_order='__name__')
    def modules(self):
        return dict(grid=modules_grid, data=modules, count=len(modules))

    @expose(template="pagedemo2.templates.modules")
    @paginate('modules', limit=1, max_pages=1)
    def modules2(self):
        return dict(modules=modules)

    @expose(template="pagedemo2.templates.grid")
    @paginate('data', max_pages=10)
    def fibonacci(self):
        F = [0, 1]
        while len(F) < 300:
            F.append(F[-1] + F[-2])
        return dict(grid=fibonacci_grid, data=enumerate(F), count=len(F))

    @expose(template="pagedemo2.templates.login")
    def login(self, forward_url=None, previous_url=None, *args, **kw):
        if not identity.current.anonymous and identity.was_login_attempted() \
                and not identity.get_identity_errors():
            redirect(url(forward_url or previous_url or '/', kw))
        forward_url = None
        previous_url = request.path
        if identity.was_login_attempted():
            msg = _("The credentials you supplied were not correct or "
                "did not grant access to this resource.")
        elif identity.get_identity_errors():
            msg = _("You must provide your credentials before accessing "
                "this resource.")
        else:
            msg = _("Please log in.")
            forward_url = request.headers.get("Referer", "/")
        response.status = 403
        return dict(message=msg, previous_url=previous_url, logging_in=True,
            original_parameters=request.params, forward_url=forward_url)

    @expose()
    def logout(self):
        identity.current.logout()
        redirect("/")
