
"""Auxiliary Widgets"""

from turbogears.widgets import Widget


class ImageLink(Widget):
    """Link with image."""

    template = """<a xmlns:py="http://purl.org/kid/ns#"
        href="$link" target="$target" title="$title"><img
        src="${tg.url('/static/images/%s.png' % src)}" alt="$title"
        title="$title" width="$width" height="$height" border="0"/></a>"""

    params = ['link', 'src', 'title', 'target', 'width', 'height']

    src = 'view'
    title = 'View'
    target = None
    width = height = 16
