
"""Italian User Generator"""

from random import choice, normalvariate, random
from string import digits, letters

first_names = """abriana alberto aldo alessandra annmarie antoneo
antonio ariana arianna armando armonie assumpta bambi belina
belio bonaventure camie camilla cammie capri caprice caprina
carina carlo carlota cianna cianni clarice claudio dangelo
domenick dona donato donette donna donnica eleonora emilio enrico
enzo fabio fabiola fabrina filippo flora florian francisca
galileo geronimo gia giada gian giana gianluca gianna gianni
giavanna ginelle giovanna giovanni giuliana giuseppe isabella
italia jianna jozef kathalina loren lorenzo lucca lucia luigi
marcelino marcello marcellus maria mariabella marietta marino
mario marzia melita mia nicandro nico omayda paolo pia pietro
primo primoz raffaello rolando rufina rupert salvator sandro
secily sicily sienna sofronio stefano tino tito tivoli tulio
tully ugo umberto valentino venecia venice victori vincenzo"""

last_names = """abbatti albernabo ale amoro andido aneri anfredini
angenis annunziattei anserminnella antoro areschini argenovese
auriero baglianchi baiani bandretti barassano bassini battei belli
benis beroni bettista bianchiaparello bocchiavoso bondini bortino
buonato caccio caetano cali campani cantinola capinelli carlatto
cavalcandro cerugini chiavonello ciprio codazzatti colo con coppolini
cortolamini costino dano davitabile defendretti devitaliparelli
donardo ducciolombo endretta eppola espossi evangenito fabriz famini
farro fierrero finziatti flaminnellegri fontano fortoni gabrielli
garo gasparelliano gentino giore giuliano grini lazzi loggio lombo
macci manci matti mazzo mily mini molito morossetti moscarlo
napoletti pacci paladini panelli pelli pettista picciolo pinti
pisantoroso politali posito pucciolombarbierrarini ramacci rizzi
robbiani rocchini roti ruso sabbiano sartelli sca schio sclafano
silviattei sola spernabo spintori sungaro testoro tibalbi tremonte
turielli ungelista valcandriz vavone ventierrugia vita"""

domain_names = """alice aspide email ciaoweb freemail freeweb gmail
gmx hotmail iol lycos juventusmail libero katamail novita postaweb
superdada tin tim tiscalinet vatican virgilio wappi webmail yahoo"""

group_names = """*Atalanta* Bergamasca Calcio S.p.A.,
*Cagliari* Calcio S.p.A., Calcio *Catania* S.p.A.
*Empoli* F.C. S.p.A., ACF *Fiorentina* S.p.A.,
*Genoa* Cricket and Football Club S.p.A.,
*Inter*nazionale Football Club S.p.A.,
*Juventus* Football Club S.p.A., *Lazio* Societa Sportiva S.p.A.,
A.S. *Livorno* Calcio S.r.l., *Milan* Associazione Calcio S.p.A.,
S.S.C. *Napoli* S.p.A., U.S. Citta di *Palermo* S.p.A.,
*Parma* Football Club S.p.A., *Reggina* Calcio S.p.A.,
*Roma* Associazione Sportiva S.p.A., *Sampdoria* Unione Calcio S.p.A.,
A.C. *Siena* S.p.A, *Torino* Football Club S.p.A.,
*Udinese* Calcio S.p.A., U.C. *Albinoleffe* S.r.l.,
*Ascoli* Calcio 1898 S.p.A., Unione Sportiva *Avellino* S.p.A.,
A.S. *Bari* S.p.A., *Bologna* Football Club 1909 S.p.A.,
*Brescia* Calcio S.p.A., A.C. *Cesena* S.p.A.,
A.C. *Chievo Verona* S.r.l., *Frosinone* Calcio S.r.l.,
U.S. *Grosseto* F.C. S.r.l., U.S. *Lecce* S.p.A.,
Associazione Calcio *Mantova* S.r.l., F.C. *Messina* Peloro S.r.l.,
F.C. *Modena* S.p.A., *Piacenza* Football Club S.p.A.,
*Pisa* Calcio S.p.A., *Ravenna* Calcio S.r.l.,
*Rimini* Calcio Football Club S.r.l., *Spezia* Calcio S.r.l.,
*Treviso* Football Club 1993 S.r.l.,
U.S. *Triestina* Calcio S.r.l., *Vicenza* Calcio S.p.A."""

first_names = map(str.capitalize, first_names.split())
last_names = map(str.capitalize, last_names.split())
domain_names = domain_names.split()
group_names = map(str.strip, group_names.split(','))

def generate_users(number=250):
    user_names = set()
    email_addresses = set()
    users = []
    for n in xrange(number):
        first_name = choice(first_names)
        last_name = choice(last_names)
        age = max(5, int(round(normalvariate(35, 10))))
        user_name = first_name.lower()
        m = 1
        while user_name in user_names:
            user_name = first_name.lower()
            if m > 1:
                user_name += str(m)
            m += 1
        user_names.add(user_name)
        password = ''.join([choice(letters)]
            + [choice(2*(first_name + last_name) + letters + digits)
                for i in range(
                    min(8, max(3, int(round(normalvariate(3, 1))))))]
            + [choice(digits)])
        domain = choice(domain_names + [last_name])
        if domain == "vatican":
            top = "va"
        elif random() < 0.5:
            top = 'it'
        else:
            top = choice(("com", "net", "org"))
        domain = "@%s.%s" % (domain, top)
        for email_address in (first_name, last_name,
                first_name + '.' + last_name,
                first_name[0] + '.' + last_name,
                first_name + '_' + last_name,
                first_name[1] + '_' + last_name,
                first_name + '_' + last_name[0],
                'super_' + first_name, user_name):
            email_address = email_address.lower() + domain
            if email_address not in email_addresses:
                break
        email_addresses.add(email_address)
        users.append(dict(user_name=user_name, password=password,
            first_name=first_name, last_name=last_name,
            age=age, email_address=email_address))
    return users

def generate_groups():
    groups = []
    for name in group_names:
        groups.append(dict(group_name=name.split('*', 2)[1],
            display_name=name.replace('*', '')))
    return groups

def set_groups(users, groups):
    groups = list(groups)
    for user in users:
        for group in sample(groups,
                min(10, max(1, int(round(normalvariate(5, 3)))))):
            user.addGroup(group)
