# Release information about pagedemo2

version = "1.0"

description = "Pagination demo application 2"
long_description = "Demo 2 for the pagination feature of TurboGears"
author = "Christoph Zwerschke"
email = "cito@online.de"
copyright = "Copyright (c) 2008 by Christoph Zwerschke"

# if it's open source, you might want to specify these
url = "http://docs.turbogears.org"
download_url = "http://docs.turbogears.org"
license = "MIT"
