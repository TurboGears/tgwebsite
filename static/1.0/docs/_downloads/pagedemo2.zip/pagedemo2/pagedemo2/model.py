
"""Paginate Demo Model"""

from datetime import datetime
from sqlobject import SQLObject, SQLObjectNotFound, RelatedJoin, \
    StringCol, UnicodeCol, IntCol, DateTimeCol
from turbogears import identity
from turbogears.database import PackageHub

__connection__ = hub = PackageHub('pagedemo2')


class Visit(SQLObject):
    """A visit to your site"""

    class sqlmeta:
        table = 'visit'

    visit_key = StringCol(length=40, alternateID=True,
        alternateMethodName='by_visit_key')
    created = DateTimeCol(default=datetime.now)
    expiry = DateTimeCol()

    def lookup_visit(cls, visit_key):
        try:
            return cls.by_visit_key(visit_key)
        except SQLObjectNotFound:
            return None
    lookup_visit = classmethod(lookup_visit)


class VisitIdentity(SQLObject):
    """A Visit that is link to a User object"""

    visit_key = StringCol(length=40, alternateID=True,
        alternateMethodName='by_visit_key')
    user_id = IntCol()


class Group(SQLObject):
    """An ultra-simple group definition."""

    class sqlmeta:
        table = 'tg_group'

    group_name = UnicodeCol(length=16, alternateID=True,
        alternateMethodName='by_group_name')
    display_name = UnicodeCol(length=255)
    created = DateTimeCol(default=datetime.now)

    users = RelatedJoin('User', intermediateTable='user_group',
        joinColumn='group_id', otherColumn='user_id')

    permissions = RelatedJoin('Permission', joinColumn='group_id',
        intermediateTable='group_permission',
        otherColumn='permission_id')

    def _get_num_members(self):
        """Get the number of group members."""
        return len(self.users)

    def _get_eldest(self):
        """"Get eldest group member."""
        eldest = None
        for user in self.users:
            if not eldest or user.age > eldest.age or (
                    user.age == eldest.age and user.id < eldest.id):
                eldest = user
        return eldest


class User(SQLObject):
    """Reasonably basic User definition."""

    class sqlmeta:
        table = 'tg_user'

    user_name = UnicodeCol(length=16, alternateID=True,
        alternateMethodName='by_user_name')
    first_name = UnicodeCol(length=128)
    last_name = UnicodeCol(length=128)
    age = IntCol()
    email_address = UnicodeCol(length=255, alternateID=True,
        alternateMethodName='by_email_address')
    password = UnicodeCol(length=40)
    created = DateTimeCol(default=datetime.now)

    groups = RelatedJoin('Group', intermediateTable='user_group',
        joinColumn='user_id', otherColumn='group_id')

    def _get_display_name(self):
        return ('%s %s' % (self.first_name or '',
            self.last_name or '')).strip()

    def _get_permissions(self):
        perms = set()
        for g in self.groups:
            perms |= set(g.permissions)
        return perms

    def _set_password(self, cleartext_password):
        password_hash = identity.encrypt_password(cleartext_password)
        self._SO_set_password(password_hash)

    def set_password_raw(self, password):
        self._SO_set_password(password)

    def _get_num_groups(self):
        """Get the number of groups where user is a member."""
        return len(self.groups)


class Permission(SQLObject):
    """A relationship that determines what each Group can do."""

    permission_name = UnicodeCol(length=16, alternateID=True,
        alternateMethodName='by_permission_name')
    description = UnicodeCol(length=255)
    groups = RelatedJoin('Group', intermediateTable='group_permission',
        joinColumn='permission_id', otherColumn='group_id')
