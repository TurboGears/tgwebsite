pagedemo2

This is a TurboGears (http://www.turbogears.org) project. It can be
started by running the start-pagedemo2.py script.
