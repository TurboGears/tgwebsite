# -*- coding: utf-8 -*-

from setuptools import setup, find_packages
from turbogears.finddata import find_package_data

import os
execfile(os.path.join("pagedemo2", "release.py"))

packages=find_packages()
package_data = find_package_data(where='pagedemo2',
    package='pagedemo2')
if os.path.isdir('locales'):
    packages.append('locales')
    package_data.update(find_package_data(where='locales',
        exclude=('*.po',), only_in_packages=False))

setup(
    name="pagedemo2",
    version=version,
    description=description,
    author=author,
    author_email=email,
    url=url,
    download_url=download_url,
    license=license,

    install_requires=[
        "TurboGears>=1.0.5,<1.1", "SQLObject"
    ],
    zip_safe=False,
    packages=packages,
    package_data=package_data,
    keywords=[
        'turbogears.app',
    ],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Framework :: TurboGears',
        'Framework :: TurboGears :: Applications',
    ],
    test_suite='nose.collector',
    entry_points = {
        'console_scripts': [
            'start-pagedemo2 = pagedemo2.commands:start',
        ],
    },
    )
