from datetime import datetime

from turbogears import controllers, expose, error_handler, validate
from turbogears import widgets, validators
from turbogears import flash

class PasswordFormSchema(validators.Schema):
    pwd1 = validators.UnicodeString(not_empty=True)
    pwd2 = validators.UnicodeString(not_empty=True)
    chained_validators = [validators.FieldsMatch('pwd1', 'pwd2'), ]

class PasswordFormFields(widgets.WidgetsList):
    pwd1 = widgets.PasswordField(label='Password:')
    pwd2 = widgets.PasswordField(label='Confirm:')

password_form = widgets.TableForm(
    name='passwordform',
    fields=PasswordFormFields(),
    validator=PasswordFormSchema()
)

class Root(controllers.RootController):

    @expose(template=".templates.form")
    def index(self, tg_errors=None):
        if tg_errors:
            flash('There was a problem with your form submission!')
        return dict(action='test', form=password_form)

    @expose()
    @validate(form=password_form)
    @error_handler(index)
    def test(self, pwd1, pwd2):
        yield "Passwords match!<br>\n"
        yield "Password 1: %s<br />Password 2: %s" % (pwd1, pwd2)
