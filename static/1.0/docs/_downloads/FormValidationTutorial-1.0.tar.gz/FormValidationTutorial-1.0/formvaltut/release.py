# Release information about FormsTutorial

version = "1.0"

description = "A simple tutorial app for TG widgets and validation schemas"
long_description = """\
This is a simple TurboGears application that shows how to generate a simple form using widgets and validation using schemas. It is part of the `FormValidationWithSchemas`_ tutorial from the TurboGears 1.0 documentation.

.. _FormValidationWithSchemas: http://docs.turbogears.org/1.0/RoughDocs/FormValidationWithSchemas
"""
author = "Michele Cella, randall@tnr.cc, Christopher Arndt"
# email = "YourEmail@YourDomain"
# copyright = "Vintage 2006 - a good year indeed"

# if it's open source, you might want to specify these
url = "http://docs.turbogears.org/1.0/RoughDocs/FormValidationWithSchemas"
download_url = "http://docs.turbogears.org/1.0/RoughDocs/FormValidationWithSchemas"
license = "MIT"
