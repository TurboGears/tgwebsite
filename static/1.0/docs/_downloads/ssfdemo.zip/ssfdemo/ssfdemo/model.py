from turbogears.database import PackageHub
from sqlobject import *

hub = PackageHub("ssfdemo")
__connection__ = hub

# class YourDataClass(SQLObject):
#     pass

