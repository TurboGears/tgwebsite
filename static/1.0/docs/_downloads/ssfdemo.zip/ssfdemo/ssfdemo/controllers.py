from turbogears import controllers, expose
import turbogears as tg
from turbogears.widgets import SingleSelectField, TableForm, WidgetsList
import random

class FormFields(WidgetsList):
    single_select = SingleSelectField(
            label = _('Prefered Framework'),
            name = 'prefered_f',
            options = [
                    (0, 'The obscure one in Ruby'),
                    (1, 'TurboGears'),
                    (2, 'The one with that guitar player name'),
                    (3, 'Pylons'),
                    (4, 'Web.py'),
                    (5, 'Zope3'),
                    (6, 'Zope2'),
                    (7, 'Twisted+Nevow'),
                    (8, 'Something super secret')],
            )

formulaire = TableForm(
        name = 'form',
        fields = FormFields(),
        action = tg.url('/post_handler'),
        submit_text = _('Vote')
        )

class Root(controllers.RootController):
    @expose(template=".templates.welcome")
    def index(self):
        pref = random.randint(0,8)
        return {'formulaire':formulaire, 'pref':pref}

    @expose()
    def post_handler(self, prefered_f):
        return "you have choosen: %s" % prefered_f

# vim: expandtab tabstop=4 shiftwidth=4:
