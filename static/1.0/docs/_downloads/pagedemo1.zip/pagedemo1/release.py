# Release information about pagedemo

version = "1.0"

description = "Pagination demo application 1"
long_description = "Demo 1 for the pagination feature of TurboGears"
author = "Adam Jones" # (some changes by Christoph Zwerschke)
email = "ajones1@gmail.com"
copyright = "Copyright (c) 2006 by Adam Jones"

# if it's open source, you might want to specify these
url = "http://docs.turbogears.org"
download_url = "http://docs.turbogears.org"
license = "MIT"
