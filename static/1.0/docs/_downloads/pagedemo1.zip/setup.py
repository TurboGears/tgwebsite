from setuptools import setup, find_packages
from turbogears.finddata import find_package_data

import os
execfile(os.path.join("pagedemo1", "release.py"))

setup(
    name="pagedemo1",
    version=version,
    author=author,
    author_email=email,
    url=url,
    download_url=download_url,
    license=license,
    install_requires = [
        "TurboGears>=0.9,<1.1", "SQLObject"
    ],
    scripts = ["start-pagedemo1.py"],
    zip_safe=False,
    packages=find_packages(),
    package_data = find_package_data(
        where='pagedemo1', package='pagedemo1'),
    keywords = [
        'turbogears.app',
    ],
    classifiers = [
        'Development Status :: 3 - Alpha',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Framework :: TurboGears',
        'Framework :: TurboGears :: Applications',
    ],
    test_suite = 'nose.collector',
    )
