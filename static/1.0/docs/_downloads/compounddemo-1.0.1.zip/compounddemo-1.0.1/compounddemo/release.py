# Release information about compounddemo

version = "1.0.1"

description = "Demo TurboGears compound widgets"
long_description = """\
This demo widget's package aims to show how to create a custom
CompoundWidget and a CompoundFormField for reusing view code amongst
templates and forms."""
author = "Alberto Valverde"
# email = "YourEmail@YourDomain"
copyright = "Vintage 2006 - a good year indeed"

# if it's open source, you might want to specify these
url = "http://docs.turbogears.org/1.0/CompoundWidgets"
download_url = "http://docs.turbogears.org/1.0/CompoundWidgets?action=AttachFile&do=get&target=compounddemo-1.0.1.tar.bz2"
license = "MIT"
