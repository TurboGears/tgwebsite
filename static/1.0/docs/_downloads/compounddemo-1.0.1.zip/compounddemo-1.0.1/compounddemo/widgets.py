"""
compounddemo. Alberto Valverde 2006
    This demo widget's package aims to show how to create a custom
    CompoundWidget and a CompoundFormField for reusing view code amongst
    templates and forms.

    It covers:
        How to define child widget's (which, of course, can also be compound).
        How to initialize them at the constructor to implement a facade pattern.
        How to override their params and value at display time.

    It doesnt cover (yet):
        How to deal with input conversion/facading. Take a look at the
        SelectShuttle's code for an example:
            http://svn.godoy.homeip.net/repos/selectshuttle


    Install it by executing:
    $ python setup.py develop
    In the project's root dir and view the examples in TG's toolbox.



    Q.
    When to choose a CompoundWidget or a CompoundFormField as a base class?

    A.
    You should use a CompoundFormField whenever the widget is intended for use
    in a form, this is, a widget that we expect to generate input for our app
    *inside* a form that's going to be submitted.

    Use a CompoundWidget otherwise, this is, widgets like a an Ajax search field
    or any other kind of widget that might generate input but noy by means of
    form submission, like in AJAX requests.



    Feel free to use and modify this code for any purpose in any way you like.
"""

import pkg_resources

from turbogears.widgets import CSSLink, JSLink, Widget, WidgetDescription, \
                               register_static_directory, CompoundWidget, \
                               TextField, SingleSelectField, CompoundFormField
from turbogears import validators

js_dir = pkg_resources.resource_filename("compounddemo",
                                         "static/javascript")
register_static_directory("compounddemo", js_dir)

class MyCompound(CompoundWidget):
    # Declare or child (member) widgets
    member_widgets = ["textfield", "selection"]
    template = """
    <div xmlns:py="http://purl.org/kid/ns#">
        ${textfield.display(value_for(textfield), **params_for(textfield))}
        ${selection.display(value_for(selection), **params_for(selection))}
    </div>
    """
    def __init__(self, tfield_params={}, sel_params={}, *args, **kw):
        # Call super cooperatively so our params get bound to the widget
        # instance
        super(MyCompound, self).__init__(*args, **kw)
        # initialize our child widgets
        self.textfield = TextField("textfield", **tfield_params)
        # Assign a default valiator to our selection field
        sel_params.setdefault('validator', validators.Int())
        self.selection = SingleSelectField("selection", **sel_params)

class MyCompoundDesc1(WidgetDescription):
    """Plain vanilla mycompound"""
    name = "MyCompound example 1"
    full_class_name = "compounddemo.MyCompound1"
    for_widget = MyCompound()

class MyCompoundDesc2(WidgetDescription):
    """Construction time passed parameter to child widgets"""
    name = "MyCompound example 2"
    full_class_name = "compounddemo.MyCompound2"
    for_widget = MyCompound(sel_params=dict(options=[(0,"foo"),(1,"bar")]))

class MyCompoundDesc3(WidgetDescription):
    """Display time passed parameters to child widgets"""
    template = """
    <div xmlns:py="http://purl.org/kid/ns#">
    ${for_widget.display(options=dict(selection=[(0,"zero"),(1,"one")]))}
    </div>

    """
    full_class_name = "compounddemo.MyCompound3"
    name = "MyCompound example 3"
    for_widget = MyCompound()

class MyCompoundDesc4(WidgetDescription):
    """Display time passed parameters and value to child widgets"""
    template = """
    <div xmlns:py="http://purl.org/kid/ns#">
    ${for_widget.display(options=dict(selection=[(0,"zero"),(1,"one")]), value=dict(selection=1))}
    </div>

    """
    name = "MyCompound example 4"
    full_class_name = "compounddemo.MyCompound4"
    for_widget = MyCompound()






class MyCompoundFormField(CompoundFormField):
    # Declare or child (member) widgets
    member_widgets = ["textfield", "selection"]
    # By using a CompoundFormField we can take advantage of some helper
    # functions to display our child widgets.
    # we can also pass a field_class parameter and a field_classes list to
    # customize the compound widget's appearance/behavior
    template = """
    <div xmlns:py="http://purl.org/kid/ns#" class="${field_class}">
        ${display_field_for(textfield)}
        ${display_field_for(selection)}
    </div>
    """

    #XXX: From here on, the code is exactly the same as in MyCompound
    #     (except in super's params, of course)
    def __init__(self, tfield_params={}, sel_params={}, *args, **kw):
        # Call super cooperatively so our params get bound to the widget
        # instance
        super(MyCompoundFormField, self).__init__(*args, **kw)
        # initialize our child widgets
        self.textfield = TextField("textfield", **tfield_params)
        # Assign a default valiator to our selection field
        sel_params.setdefault('validator', validators.Int())
        self.selection = SingleSelectField("selection", **sel_params)







class MyCompoundFormFieldDesc1(WidgetDescription):
    """Plain vanilla mycompoundformfield"""
    name = "MyCompoundFormField example 1"
    full_class_name = "compounddemo.MyCompoundFormField1"
    for_widget = MyCompoundFormField()

class MyCompoundFormFieldDesc2(WidgetDescription):
    """Construction time passed parameter to child widgets"""
    name = "MyCompoundFormField example 2"
    full_class_name = "compounddemo.MyCompoundFormField2"
    for_widget = MyCompoundFormField(sel_params=dict(options=[(0,"foo"),(1,"bar")]))

class MyCompoundFormFieldDesc3(WidgetDescription):
    """Display time passed parameters to child widgets"""
    template = """
    <div xmlns:py="http://purl.org/kid/ns#">
    ${for_widget.display(options=dict(selection=[(0,"zero"),(1,"one")]))}
    </div>

    """
    full_class_name = "compounddemo.MyCompoundFormField3"
    name = "MyCompoundFormField example 3"
    for_widget = MyCompoundFormField()

class MyCompoundFormFieldDesc4(WidgetDescription):
    """Display time passed parameters and value to child widgets"""
    template = """
    <div xmlns:py="http://purl.org/kid/ns#">
    ${for_widget.display(options=dict(selection=[(0,"zero"),(1,"one")]), value=dict(selection=1))}
    </div>

    """
    name = "MyCompoundFormField example 4"
    full_class_name = "compounddemo.MyCompound4"
    for_widget = MyCompound()
