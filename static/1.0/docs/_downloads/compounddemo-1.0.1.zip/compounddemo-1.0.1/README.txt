CompoundDemo
============

This is a TurboGears (http://www.turbogears.org) widget project.
You can view the widgets in the Toolbox.

This demo widget's package aims to show how to create a custom
CompoundWidget and a CompoundFormField for reusing view code amongst
templates and forms.

It covers:
    How to define child widget's (which, of course, can also be compound).
    How to initialize them at the constructor to implement a facade pattern.
    How to override their params and value at display time.

It doesnt cover (yet):
    How to deal with input conversion/facading. Take a look at the
    SelectShuttle's code for an example:
        http://svn.godoy.homeip.net/repos/selectshuttle


Install it by executing:
$ python setup.py develop
In the project's root dir and view the examples in TG's toolbox.



Q.
When to choose a CompoundWidget or a CompoundFormField as a base class?

A.
You should use a CompoundFormField whenever the widget is intended for use
in a form, this is, a widget that we expect to generate input for our app
*inside* a form that's going to be submitted.

Use a CompoundWidget otherwise, this is, widgets like a an Ajax search field
or any other kind of widget that might generate input but noy by means of
form submission, like in AJAX requests.

Feel free to use and modify this code for any purpose in any way you like.
