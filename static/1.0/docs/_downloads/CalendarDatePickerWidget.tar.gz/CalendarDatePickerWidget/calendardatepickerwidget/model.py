import datetime

from sqlobject import *

from turbogears.database import PackageHub


hub = PackageHub("calendardatepickerwidget")
__connection__ = hub
