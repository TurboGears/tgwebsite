import locale
from datetime import datetime

from turbogears import controllers, expose, error_handler, validate
from turbogears import flash, redirect, url
from turbogears import widgets, validators
import turbogears

#import calendardatepickerwidget.model

# set the locale so that we can show the date in local format
locale.setlocale(locale.LC_ALL, '')

class Activities(list):
    """A very simple storage class for activities."""

    def add(self, activityName, activityDate):
        self.append((activityName, activityDate))
                
activities = Activities()   

class ActivityFormFields(widgets.WidgetsList):
    ''' A list of fields for our activity form. '''

    activityName = widgets.TextField(
        label = _('Activity Name'),
        name = 'activityName',
        validator = validators.NotEmpty())

    activityDate = widgets.CalendarDatePicker(
        label = _('Activity Date'),
        name = 'activityDate',
        format = '%d/%m/%Y',
        validator = validators.DateTimeConverter(format="%d/%m/%Y", not_empty=True))
    
    
activityForm = widgets.TableForm(
    'ActivityForm',
    fields = ActivityFormFields(),
    action = 'saveActivity',
    submit_text = _('Save Activity'))

    
class Root(controllers.RootController):
    
    @expose(template="calendardatepickerwidget.templates.index")
    def index(self):
        """ Display the activities. """
        
        return dict(activities=activities)

    @expose(template='.templates.add')
    def add(self, tg_errors=None):
        """Show the activity form."""
        
        if tg_errors:
            flash('There was a problem with the form!')
        return dict(form=activityForm)
    
    @expose()
    @error_handler(add)
    @validate(form=activityForm)
    @validate(validators={'activityDate':validators.DateValidator(after_now=True)})
    def saveActivity(self, activityName, activityDate):
        """Handle submission from the activity form and save the activity."""

        activities.add(activityName, activityDate)
        flash('Activity added!')
        redirect('/')
        