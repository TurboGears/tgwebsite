# Release information about CustomIdentity

version = "1.0.1"

description = "A TurboGears 1.1 demo application with a custom identity provider."
# long_description = "More description about your plan"
author = "Christopher Arndt"
email = "chris@chrisarndt.de"
copyright = "Copyright 2009 - as good a year as any"

# if it's open source, you might want to specify these
url = "http://docs.turbogears.org/1.0/IdentityRecipes"
download_url = url
license = "MIT"
