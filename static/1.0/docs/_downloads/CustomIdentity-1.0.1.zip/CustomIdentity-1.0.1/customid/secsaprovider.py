"""Module implementing a custom TurboGears identity provider with additional
security checks.

Only SQLAlchemy identity models are supported at the moment.

Copy this file into your applications's package (the package name ``yourpkg``
is used in the examples below.). Then the ``SecSAIdentityProvider`` class must
be added as an entry point for 'turbogears.identity.provider' to the
application's 'setup.py' file by adding the following lines

::

        'turbogears.identity.provider': [
            'secsaprovider = yourpkg.secsaprovider:SecSAIdentityProvider'
        ]

to the ``entry_points`` dictionary in the ``setup()`` call. Don't forget to
install the application with easy_install afterwards or run
``"python setup.py develop"``!

The provider plugin can then be activated as the identity provider to use in
your by application by setting the following in ``app.cfg``::

    identity.provider = 'secsaprovider'

The SecSAIdentityProvider class uses the following additional application
configuration settings (given values are the default values). The names
should speak for themselves::

    identity.secsaprovider.pw_max_age = 120                # in days
    identity.secsaprovider.lockout_time = 300              # in seconds
    identity.secsaprovider.max_failed_login_attempts = 3

You may want to add these to your application's ``appp.cfg`` or deployment
configuration and change them as you see fit.

For the additional security checks by this identity provider, the User model
object needs to define the following properties in addition to the standard
SQLAlchemy identity model::

    Column('password_changed', DateTime, default=datetime.now),
    Column('password_max_age', Integer,
        default=config.get('identity.secsaprovider.pw_max_age', 90)),
    Column('last_login_attempt', DateTime),
    Column('failed_login_attempts', Integer, default=0),

If these properties are not present, the identity provider should still work,
but the additional security checks will be practically no-ops.

"""

import datetime
import logging

import cherrypy

from turbogears import config
from turbogears.util import load_class
from turbogears.identity import (IdentityFailure, get_failure_url,
    set_current_identity, set_identity_errors)
from turbogears.identity.saprovider import (SqlAlchemyIdentity,
    SqlAlchemyIdentityProvider)

# Change 'customid' here to the name of your application's package on the
# following line!
log = logging.getLogger('customid.identity')


class SecSAIdentityProvider(SqlAlchemyIdentityProvider):
    """Custom IdentityProvider implementing additional password checks.
    """

    def __init__(self):
        super(SecSAIdentityProvider, self).__init__()
        get = config.get
        user_class_path = get("identity.saprovider.model.user", None)
        self.user_class = load_class(user_class_path)
        self.default_pw_max_age = get('identity.secsaprovider.pw_max_age', 120)
        self.lockout_time = get('identity.secsaprovider.lockout_time', 600)
        self.max_failed_attempts = get(
            'identity.secsaprovider.max_failed_login_attempts', 3)

    def validate_identity(self, user_name, password, visit_key):
        """Validate the identity represented by user_name using the password.

        May either return None if the credentials weren't valid or an object
        conforming to the TurboGears identity interface:

            http://docs.turbogears.org/1.0/UsingIdentity#identity-current-interface

        It is also possible to call ``self.authentication_error()`` with any
        error messages as positional parameters to redirect directly to the
        identity.failure_url and set the identity error message(s).

        """
        user = self.user_class.query.filter_by(user_name=user_name).first()
        if not user:
            log.warning("No such user: %s", user_name)
            return None

        # User exists -->
        # Check for past failed login attempts
        now = datetime.datetime.now()
        failed_attempts = getattr(user, 'failed_login_attempts', 0)
        last_attempt = getattr(user, 'last_login_attempt',
            datetime.datetime(datetime.MINYEAR, 1, 1))
        user.last_login_attempt = now

        if not failed_attempts:
            failed_attempts = 0

        if failed_attempts >= self.max_failed_attempts:
            if (now - last_attempt).seconds < self.lockout_time:
                log.info("Too many (%i, max %i) failed login attempts for user '%s'.",
                    failed_attempts, self.max_failed_attempts, user_name)
                log.info("User locked out until %s",
                    now + datetime.timedelta(seconds=self.lockout_time))
                self.authentication_error(
                    u"Your account has been suspended due to too many failed "
                    u"login attempts.\nYou may try again in %i minutes." %
                    (self.lockout_time / 60,))
            else:
                failed_attempts = 0

        # Finallly ,check password
        if not self.validate_password(user, user_name, password):
            log.info("Passwords don't match for user '%s'.", user_name)
            log.info("Failed login attempts: %i", failed_attempts)
            failed_attempts += 1
            user.failed_login_attempts = failed_attempts
            self.authentication_error(
                u"The username or password you supplied is not correct.")

        # Check if password has expired
        pw_changed = getattr(user, 'password_changed', None)
        if pw_changed is None:
            pw_changed = user.created
            log.warning("Last password change time not set for user '%s'.",
                user_name)
            log.warning("Using creation time (%s) instead.", pw_changed)
        pw_max_age = getattr(user, 'password_max_age', None)
        # Important: 0 is a valid value, so check for 'is None'
        if pw_max_age is None:
            pw_max_age = self.default_pw_max_age
        pw_expiration = pw_changed + datetime.timedelta(days=pw_max_age)
        if pw_max_age != 0 and now > pw_expiration:
            log.info("Password expired for user '%s'.", user_name)
            log.info("Last changed: %s, age: %i days, max-age: %i days",
                pw_changed, (now - pw_changed).days, pw_max_age)
            self.authentication_error(u"Your password has expired. "
                u"Please contact your system administrator to have it reset.")

        # User can log in
        user.failed_login_attempts = 0
        log.info("Associating user '%s' with visit '%s'.", user_name, visit_key)
        return SqlAlchemyIdentity(visit_key, user)

    def authentication_error(self, *errors):
        """Redirects to identity failure URL and set identity error message.

        We do this here instead of raising an IdentityFailure exception,
        because raising an IdentityException in the authentication phase, i.e.
        in the ``turbogears.identity.IdentityVisitPugin.record_request()``
        method, will not work properly because the exception will be caught and
        the error message replaced with a generic one, which is not what we
        want.

        Takes any number of error messages as positional parameters, which
        will be set as the identity error messages, which then can be used
        by the login method with ``identity.get_identity_errors()``.

        """
        set_current_identity(self.anonymous_identity())
        set_identity_errors(errors)
        url = get_failure_url(errors)
        cherrypy.response.status = 401

        if config.get('identity.force_external_redirect', False):
            # We need to use external redirect for https since we are managed
            # by Apache/nginx or something else that CherryPy won't find.
            # We also need to set the forward_url, because the Referer header
            # won't work with an external redirect.
            params = cherrypy.request.params
            params['forward_url'] = cherrypy.request.path_info
            raise cherrypy.HTTPRedirect(turbogears.url(url, params))
        else:
            # use internal redirect which is quicker
            raise cherrypy.InternalRedirect(url)
