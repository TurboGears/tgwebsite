CustomIdentity
==============

:Author: Christopher Arndt
:Date: 2009-03-27


This is a TurboGears 1.1 (http://www.turbogears.org) project that demonstrates
how to implement and use a custom identity provider.

The custom identity provider implements the following additional checks in
the authentication phase:

  * It records the number of failed login attempts for each user and
    locks the user out for a certain amount of time if there have been to
    many failed log in attempts.
  * It checks the password "freshness" of each user when he tries to log in.
    If the time of the last password change is too long ago, he will not be
    permitted to log in. The password expiration time can be set globally in
    the configuration or on a per-user basis in the database.


Quickstart
----------

1. Unpack the source distribution, open a terminal in the project directory
   and run ``"python setup.py develop"`` or ``"easy_install ."`` to install
   the application. The cutom identity provider plug-in will not work without
   this step!

2. Run ``"bootstrap-customid -u test"`` in the same directory to create the
   database and a default user with the user name "test". It will ask for a
   password for the "test" user interactively.

3. Start the application with the ``"start-customid"`` command.

4. Open your webbrowser at ``http://localhost:8080/`` and try logging in.
   Try logging in with a wrong passowrd three times then a fourth time with the
   correct password. This time it should tell you that you have been locked out
   for 5 minutes. Try again with the correct password after 5 minutes and it
   should let you in again.


Further tests
-------------

To test the password expiration feature, you must set the ``password_max_age``
attribute of the "test" user to some integer value and then set his
``password_changed`` attribute value to a date more than ``password_max_age``
days in the past. You can do this through the interactive interpeter like so::

    $ tg-admin shell
    >>> import datetime
    >>> u = User.by_user_name(u'test')
    >>> u.password_max_age = 14
    >>> u.password_changed = datetime.datetime.now() - \
        datetime.timedelta(days=-21)
    >>> session.flush()

The start the application again and try to login. The login form should show
a message that the password has expired. To reset the password, just set the
``password_changed`` attribute of your test user to ``.datatime.datetime.now()``
using the procdure explained above.


Further information
-------------------

For implementation details, see the docstrings of the ``customid.secsaprovider``
module.


Changelog
---------

* 1.0.1 (2009-09-16) Chris Arndt

  - Updated templates to use new 1.1 design
  - Added instructions to reset password expiration to README

* 1.0 (2009-03-27) Chris Arndt

  - Initial release
